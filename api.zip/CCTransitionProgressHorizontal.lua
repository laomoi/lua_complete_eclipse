-- @module CCTransitionProgressHorizontal

-----------------------
-- @function [parent=#CCTransitionProgressHorizontal] create
-- @param  t
-- @param  scene

-----------------------
return nil
