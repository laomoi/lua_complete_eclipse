-- @module CCTransitionFadeBL

-----------------------
-- @function [parent=#CCTransitionFadeBL] create
-- @param  t
-- @param  scene

-----------------------
return nil
