-- @module CCScaleTo

-----------------------
-- @function [parent=#CCScaleTo] create
-- @param  duration
-- @param  sx
-- @param  sy

-----------------------
-- @function [parent=#CCScaleTo] create
-- @param  duration
-- @param  s

-----------------------
return nil
