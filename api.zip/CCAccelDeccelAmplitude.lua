-- @module CCAccelDeccelAmplitude

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] getRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] setRate
-- @param  self
-- @param  fRate

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
