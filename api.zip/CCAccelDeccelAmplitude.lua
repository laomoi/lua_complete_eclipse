-- @module CCAccelDeccelAmplitude

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] getRate
-- @param  void

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] setRate
-- @param  fRate

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
