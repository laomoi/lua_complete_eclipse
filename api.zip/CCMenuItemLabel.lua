-- @module CCMenuItemLabel

-----------------------
-- @function [parent=#CCMenuItemLabel] setString
-- @param  label

-----------------------
-- @function [parent=#CCMenuItemLabel] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemLabel] getOpacity

-----------------------
-- @function [parent=#CCMenuItemLabel] setColor
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemLabel] getColor

-----------------------
-- @function [parent=#CCMenuItemLabel] setDisabledColor
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemLabel] getDisabledColor

-----------------------
-- @function [parent=#CCMenuItemLabel] setLabel
-- @param  pLabel

-----------------------
-- @function [parent=#CCMenuItemLabel] getLabel

-----------------------
-- @function [parent=#CCMenuItemLabel] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCMenuItemLabel] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCMenuItemLabel] create
-- @param  label

-----------------------
return nil
