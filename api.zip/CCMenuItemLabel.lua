-- @module CCMenuItemLabel

-----------------------
-- @function [parent=#CCMenuItemLabel] setString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCMenuItemLabel] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemLabel] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemLabel] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemLabel] getColor
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemLabel] setDisabledColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemLabel] getDisabledColor
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemLabel] setLabel
-- @param  self
-- @param  pLabel

-----------------------
-- @function [parent=#CCMenuItemLabel] getLabel
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemLabel] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCMenuItemLabel] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenuItemLabel] create
-- @param  label

-----------------------
return nil
