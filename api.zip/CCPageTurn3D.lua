-- @module CCPageTurn3D

-----------------------
-- @function [parent=#CCPageTurn3D] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
