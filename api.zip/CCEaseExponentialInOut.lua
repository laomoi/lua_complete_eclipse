-- @module CCEaseExponentialInOut

-----------------------
-- @function [parent=#CCEaseExponentialInOut] create
-- @param  pAction

-----------------------
return nil
