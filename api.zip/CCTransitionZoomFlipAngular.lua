-- @module CCTransitionZoomFlipAngular

-----------------------
-- @function [parent=#CCTransitionZoomFlipAngular] create
-- @param  t
-- @param  s
-- @param  kCCTransitionOrientationRightOver

-----------------------
return nil
