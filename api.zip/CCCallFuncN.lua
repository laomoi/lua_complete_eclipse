-- @module CCCallFuncN

-----------------------
-- @function [parent=#CCCallFuncN] create
-- @param  funcID

-----------------------
return nil
