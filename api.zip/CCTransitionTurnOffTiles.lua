-- @module CCTransitionTurnOffTiles

-----------------------
-- @function [parent=#CCTransitionTurnOffTiles] create
-- @param  t
-- @param  scene

-----------------------
return nil
