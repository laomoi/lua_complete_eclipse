-- @module CCAccelAmplitude

-----------------------
-- @function [parent=#CCAccelAmplitude] getRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAccelAmplitude] setRate
-- @param  self
-- @param  fRate

-----------------------
-- @function [parent=#CCAccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
