-- @module CCAccelAmplitude

-----------------------
-- @function [parent=#CCAccelAmplitude] getRate
-- @param  void

-----------------------
-- @function [parent=#CCAccelAmplitude] setRate
-- @param  fRate

-----------------------
-- @function [parent=#CCAccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
