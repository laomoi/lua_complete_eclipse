-- @module CCParticleExplosion

-----------------------
-- @function [parent=#CCParticleExplosion] create

-----------------------
return nil
