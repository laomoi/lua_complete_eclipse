-- @module CCSize

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSize] equals
-- @param  self
-- @param  target

-----------------------
return nil
