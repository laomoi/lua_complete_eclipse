-- @module CCSize

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCSize] CCSize
-- @param  void

-----------------------
-- @function [parent=#CCSize] equals
-- @param  target

-----------------------
return nil
