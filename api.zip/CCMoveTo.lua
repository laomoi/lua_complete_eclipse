-- @module CCMoveTo

-----------------------
-- @function [parent=#CCMoveTo] create
-- @param  duration
-- @param  position

-----------------------
return nil
