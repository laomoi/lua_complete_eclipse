-- @module CCGridAction

-----------------------
-- @function [parent=#CCGridAction] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
