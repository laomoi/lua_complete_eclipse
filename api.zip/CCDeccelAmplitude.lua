-- @module CCDeccelAmplitude

-----------------------
-- @function [parent=#CCDeccelAmplitude] getRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCDeccelAmplitude] setRate
-- @param  self
-- @param  fRate

-----------------------
-- @function [parent=#CCDeccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
