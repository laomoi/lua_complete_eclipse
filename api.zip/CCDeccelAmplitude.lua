-- @module CCDeccelAmplitude

-----------------------
-- @function [parent=#CCDeccelAmplitude] getRate
-- @param  void

-----------------------
-- @function [parent=#CCDeccelAmplitude] setRate
-- @param  fRate

-----------------------
-- @function [parent=#CCDeccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
