-- @module CCTextureCache

-----------------------
-- @function [parent=#CCTextureCache] addImage
-- @param  fileimage

-----------------------
-- @function [parent=#CCTextureCache] addUIImage
-- @param  image
-- @param  key

-----------------------
-- @function [parent=#CCTextureCache] addPVRImage
-- @param  filename

-----------------------
-- @function [parent=#CCTextureCache] textureForKey
-- @param  key

-----------------------
-- @function [parent=#CCTextureCache] removeAllTextures

-----------------------
-- @function [parent=#CCTextureCache] removeUnusedTextures

-----------------------
-- @function [parent=#CCTextureCache] removeTexture
-- @param  texture

-----------------------
-- @function [parent=#CCTextureCache] removeTextureForKey
-- @param  textureKeyName

-----------------------
-- @function [parent=#CCTextureCache] dumpCachedTextureInfo

-----------------------
-- @function [parent=#CCTextureCache] sharedTextureCache

-----------------------
-- @function [parent=#CCTextureCache] reloadAllTextures

-----------------------
-- @function [parent=#CCTextureCache] purgeSharedTextureCache

-----------------------
return nil
