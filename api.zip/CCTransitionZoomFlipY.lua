-- @module CCTransitionZoomFlipY

-----------------------
-- @function [parent=#CCTransitionZoomFlipY] create
-- @param  t
-- @param  s
-- @param  kCCTransitionOrientationUpOver

-----------------------
return nil
