-- @module CCShuffleTiles

-----------------------
-- @function [parent=#CCShuffleTiles] shuffle
-- @param  self
-- @param  pArray
-- @param  nLen

-----------------------
-- @function [parent=#CCShuffleTiles] getDelta
-- @param  self
-- @param  pos

-----------------------
-- @function [parent=#CCShuffleTiles] create
-- @param  duration
-- @param  gridSize
-- @param  seed

-----------------------
return nil
