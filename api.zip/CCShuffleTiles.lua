-- @module CCShuffleTiles

-----------------------
-- @function [parent=#CCShuffleTiles] shuffle
-- @param  pArray
-- @param  nLen

-----------------------
-- @function [parent=#CCShuffleTiles] getDelta
-- @param  pos

-----------------------
-- @function [parent=#CCShuffleTiles] placeTile
-- @param  pos
-- @param  t

-----------------------
-- @function [parent=#CCShuffleTiles] create
-- @param  duration
-- @param  gridSize
-- @param  seed

-----------------------
return nil
