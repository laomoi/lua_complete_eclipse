-- @module CCTMXTiledMap

-----------------------
-- @function [parent=#CCTMXTiledMap] setMapSize
-- @param  sz

-----------------------
-- @function [parent=#CCTMXTiledMap] getMapSize

-----------------------
-- @function [parent=#CCTMXTiledMap] setTileSize
-- @param  sz

-----------------------
-- @function [parent=#CCTMXTiledMap] getTileSize

-----------------------
-- @function [parent=#CCTMXTiledMap] setMapOrientation
-- @param  val

-----------------------
-- @function [parent=#CCTMXTiledMap] getMapOrientation

-----------------------
-- @function [parent=#CCTMXTiledMap] setObjectGroups
-- @param  pval

-----------------------
-- @function [parent=#CCTMXTiledMap] getObjectGroups

-----------------------
-- @function [parent=#CCTMXTiledMap] setProperties
-- @param  pval

-----------------------
-- @function [parent=#CCTMXTiledMap] getProperties

-----------------------
-- @function [parent=#CCTMXTiledMap] layerNamed
-- @param  layerName

-----------------------
-- @function [parent=#CCTMXTiledMap] objectGroupNamed
-- @param  groupName

-----------------------
-- @function [parent=#CCTMXTiledMap] propertyNamed
-- @param  propertyName

-----------------------
-- @function [parent=#CCTMXTiledMap] propertiesForGID
-- @param  GID

-----------------------
-- @function [parent=#CCTMXTiledMap] create
-- @param  tmxFile

-----------------------
-- @function [parent=#CCTMXTiledMap] createWithXML
-- @param  tmxString
-- @param  resourcePath

-----------------------
return nil
