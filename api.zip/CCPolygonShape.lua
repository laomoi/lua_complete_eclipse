-- @module CCPolygonShape

-----------------------
-- @function [parent=#CCPolygonShape] create
-- @param  vertices

-----------------------
-- @function [parent=#CCPolygonShape] isFill
-- @param  void

-----------------------
-- @function [parent=#CCPolygonShape] setFill
-- @param  fill

-----------------------
-- @function [parent=#CCPolygonShape] isClose
-- @param  void

-----------------------
-- @function [parent=#CCPolygonShape] setClose
-- @param  close

-----------------------
return nil
