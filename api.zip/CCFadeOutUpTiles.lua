-- @module CCFadeOutUpTiles

-----------------------
-- @function [parent=#CCFadeOutUpTiles] transformTile
-- @param  pos
-- @param  distance

-----------------------
-- @function [parent=#CCFadeOutUpTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
