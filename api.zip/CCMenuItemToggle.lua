-- @module CCMenuItemToggle

-----------------------
-- @function [parent=#CCMenuItemToggle] setColor
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemToggle] getColor

-----------------------
-- @function [parent=#CCMenuItemToggle] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemToggle] getOpacity

-----------------------
-- @function [parent=#CCMenuItemToggle] setSelectedIndex
-- @param  index

-----------------------
-- @function [parent=#CCMenuItemToggle] getSelectedIndex

-----------------------
-- @function [parent=#CCMenuItemToggle] setSubItems
-- @param  pArrayOfItems

-----------------------
-- @function [parent=#CCMenuItemToggle] getSubItems

-----------------------
-- @function [parent=#CCMenuItemToggle] addSubItem
-- @param  item

-----------------------
-- @function [parent=#CCMenuItemToggle] selectedItem

-----------------------
-- @function [parent=#CCMenuItemToggle] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCMenuItemToggle] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCMenuItemToggle] create
-- @param  item

-----------------------
return nil
