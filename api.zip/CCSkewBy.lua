-- @module CCSkewBy

-----------------------
-- @function [parent=#CCSkewBy] create
-- @param  t
-- @param  deltaSkewX
-- @param  deltaSkewY

-----------------------
return nil
