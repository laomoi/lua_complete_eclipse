-- @module CCRect

-----------------------
-- @function [parent=#CCRect] CCRect
-- @param  x
-- @param  y
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCRect] CCRect
-- @param  void

-----------------------
-- @function [parent=#CCRect] getMinX

-----------------------
-- @function [parent=#CCRect] getMidX

-----------------------
-- @function [parent=#CCRect] getMaxX

-----------------------
-- @function [parent=#CCRect] getMinY

-----------------------
-- @function [parent=#CCRect] getMidY

-----------------------
-- @function [parent=#CCRect] getMaxY

-----------------------
-- @function [parent=#CCRect] equals
-- @param  rect

-----------------------
-- @function [parent=#CCRect] containsPoint
-- @param  point

-----------------------
-- @function [parent=#CCRect] intersectsRect
-- @param  rect

-----------------------
return nil
