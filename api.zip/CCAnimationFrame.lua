-- @module CCAnimationFrame

-----------------------
-- @function [parent=#CCAnimationFrame] getSpriteFrame
-- @param  self

-----------------------
-- @function [parent=#CCAnimationFrame] setSpriteFrame
-- @param  self
-- @param  pSpFrame

-----------------------
-- @function [parent=#CCAnimationFrame] getDelayUnits
-- @param  self

-----------------------
-- @function [parent=#CCAnimationFrame] setDelayUnits
-- @param  self
-- @param  fDelayUnits

-----------------------
-- @function [parent=#CCAnimationFrame] getUserInfo
-- @param  self

-----------------------
-- @function [parent=#CCAnimationFrame] setUserInfo
-- @param  self
-- @param  pDict

-----------------------
return nil
