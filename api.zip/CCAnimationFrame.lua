-- @module CCAnimationFrame

-----------------------
-- @function [parent=#CCAnimationFrame] getSpriteFrame

-----------------------
-- @function [parent=#CCAnimationFrame] setSpriteFrame
-- @param  pSpFrame

-----------------------
-- @function [parent=#CCAnimationFrame] getDelayUnits

-----------------------
-- @function [parent=#CCAnimationFrame] setDelayUnits
-- @param  fDelayUnits

-----------------------
-- @function [parent=#CCAnimationFrame] getUserInfo

-----------------------
-- @function [parent=#CCAnimationFrame] setUserInfo
-- @param  pDict

-----------------------
return nil
