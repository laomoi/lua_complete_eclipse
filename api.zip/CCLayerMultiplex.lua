-- @module CCLayerMultiplex

-----------------------
-- @function [parent=#CCLayerMultiplex] addLayer
-- @param  layer

-----------------------
-- @function [parent=#CCLayerMultiplex] switchTo
-- @param  n

-----------------------
-- @function [parent=#CCLayerMultiplex] switchToAndReleaseMe
-- @param  n

-----------------------
-- @function [parent=#CCLayerMultiplex] create
-- @param  layer

-----------------------
-- @function [parent=#CCLayerMultiplex] createWithLayer
-- @param  layer

-----------------------
return nil
