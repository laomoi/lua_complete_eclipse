-- @module CCLayerMultiplex

-----------------------
-- @function [parent=#CCLayerMultiplex] addLayer
-- @param  self
-- @param  layer

-----------------------
-- @function [parent=#CCLayerMultiplex] switchTo
-- @param  self
-- @param  n

-----------------------
-- @function [parent=#CCLayerMultiplex] switchToAndReleaseMe
-- @param  self
-- @param  n

-----------------------
-- @function [parent=#CCLayerMultiplex] create
-- @param  layer

-----------------------
-- @function [parent=#CCLayerMultiplex] createWithLayer
-- @param  layer

-----------------------
return nil
