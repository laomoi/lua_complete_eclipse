-- @module CCWavesTiles3D

-----------------------
-- @function [parent=#CCWavesTiles3D] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCWavesTiles3D] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCWavesTiles3D] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCWavesTiles3D] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCWavesTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude

-----------------------
return nil
