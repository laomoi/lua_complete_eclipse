-- @module CCWavesTiles3D

-----------------------
-- @function [parent=#CCWavesTiles3D] getAmplitude
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCWavesTiles3D] setAmplitude
-- @param  self
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCWavesTiles3D] getAmplitudeRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCWavesTiles3D] setAmplitudeRate
-- @param  self
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCWavesTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude

-----------------------
return nil
