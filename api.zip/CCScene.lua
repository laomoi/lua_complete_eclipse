-- @module CCScene

-----------------------
-- @function [parent=#CCScene] create
-- @param  void

-----------------------
return nil
