-- @module CCSpeed

-----------------------
-- @function [parent=#CCSpeed] getSpeed
-- @param  void

-----------------------
-- @function [parent=#CCSpeed] setSpeed
-- @param  fSpeed

-----------------------
-- @function [parent=#CCSpeed] create
-- @param  pAction
-- @param  fRate

-----------------------
return nil
