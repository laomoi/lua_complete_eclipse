-- @module CCCrypto

-----------------------
-- @function [parent=#CCCrypto] getAES256KeyLength
-- @param  void

-----------------------
-- @function [parent=#CCCrypto] encodeBase64Lua
-- @param  input
-- @param  inputLength

-----------------------
-- @function [parent=#CCCrypto] decodeBase64Lua
-- @param  input

-----------------------
-- @function [parent=#CCCrypto] MD5Lua
-- @param  input
-- @param  isRawOutput

-----------------------
-- @function [parent=#CCCrypto] sha1Lua
-- @param  input
-- @param  key
-- @param  isRawOutput

-----------------------
return nil
