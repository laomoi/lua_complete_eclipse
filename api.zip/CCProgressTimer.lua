-- @module CCProgressTimer

-----------------------
-- @function [parent=#CCProgressTimer] getType
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getPercentage
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getSprite
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setPercentage
-- @param  fPercentage

-----------------------
-- @function [parent=#CCProgressTimer] setSprite
-- @param  pSprite

-----------------------
-- @function [parent=#CCProgressTimer] setType
-- @param  type

-----------------------
-- @function [parent=#CCProgressTimer] setReverseProgress
-- @param  reverse

-----------------------
-- @function [parent=#CCProgressTimer] setAnchorPoint
-- @param  anchorPoint

-----------------------
-- @function [parent=#CCProgressTimer] setColor
-- @param  color

-----------------------
-- @function [parent=#CCProgressTimer] getColor
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCProgressTimer] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCProgressTimer] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getMidpoint

-----------------------
-- @function [parent=#CCProgressTimer] setMidpoint
-- @param  pt

-----------------------
-- @function [parent=#CCProgressTimer] getBarChangeRate

-----------------------
-- @function [parent=#CCProgressTimer] setBarChangeRate
-- @param  rate

-----------------------
-- @function [parent=#CCProgressTimer] isReverseDirection

-----------------------
-- @function [parent=#CCProgressTimer] setReverseDirection
-- @param  bReverseDir

-----------------------
-- @function [parent=#CCProgressTimer] create
-- @param  sp

-----------------------
return nil
