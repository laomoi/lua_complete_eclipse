-- @module CCProgressTimer

-----------------------
-- @function [parent=#CCProgressTimer] getType
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getPercentage
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getSprite
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setPercentage
-- @param  self
-- @param  fPercentage

-----------------------
-- @function [parent=#CCProgressTimer] setSprite
-- @param  self
-- @param  pSprite

-----------------------
-- @function [parent=#CCProgressTimer] setType
-- @param  self
-- @param  type

-----------------------
-- @function [parent=#CCProgressTimer] setReverseProgress
-- @param  self
-- @param  reverse

-----------------------
-- @function [parent=#CCProgressTimer] setAnchorPoint
-- @param  self
-- @param  anchorPoint

-----------------------
-- @function [parent=#CCProgressTimer] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCProgressTimer] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCProgressTimer] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCProgressTimer] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] getMidpoint
-- @param  self

-----------------------
-- @function [parent=#CCProgressTimer] setMidpoint
-- @param  self
-- @param  pt

-----------------------
-- @function [parent=#CCProgressTimer] getBarChangeRate
-- @param  self

-----------------------
-- @function [parent=#CCProgressTimer] setBarChangeRate
-- @param  self
-- @param  rate

-----------------------
-- @function [parent=#CCProgressTimer] isReverseDirection
-- @param  self

-----------------------
-- @function [parent=#CCProgressTimer] setReverseDirection
-- @param  self
-- @param  bReverseDir

-----------------------
-- @function [parent=#CCProgressTimer] create
-- @param  sp

-----------------------
return nil
