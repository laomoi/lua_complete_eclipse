-- @module CCTMXObjectGroup

-----------------------
-- @function [parent=#CCTMXObjectGroup] setPositionOffset
-- @param  pt

-----------------------
-- @function [parent=#CCTMXObjectGroup] getPositionOffset

-----------------------
-- @function [parent=#CCTMXObjectGroup] setProperties
-- @param  pval

-----------------------
-- @function [parent=#CCTMXObjectGroup] getProperties

-----------------------
-- @function [parent=#CCTMXObjectGroup] setObjects
-- @param  val

-----------------------
-- @function [parent=#CCTMXObjectGroup] getObjects

-----------------------
-- @function [parent=#CCTMXObjectGroup] setGroupName
-- @param  groupName

-----------------------
-- @function [parent=#CCTMXObjectGroup] getGroupName

-----------------------
-- @function [parent=#CCTMXObjectGroup] propertyNamed
-- @param  propertyName

-----------------------
-- @function [parent=#CCTMXObjectGroup] objectNamed
-- @param  objectName

-----------------------
return nil
