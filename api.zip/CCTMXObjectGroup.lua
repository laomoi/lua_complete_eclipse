-- @module CCTMXObjectGroup

-----------------------
-- @function [parent=#CCTMXObjectGroup] setPositionOffset
-- @param  self
-- @param  pt

-----------------------
-- @function [parent=#CCTMXObjectGroup] getPositionOffset
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] setProperties
-- @param  self
-- @param  pval

-----------------------
-- @function [parent=#CCTMXObjectGroup] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] setObjects
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCTMXObjectGroup] getObjects
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] setGroupName
-- @param  self
-- @param  groupName

-----------------------
-- @function [parent=#CCTMXObjectGroup] getGroupName
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] objectNamed
-- @param  self
-- @param  objectName

-----------------------
return nil
