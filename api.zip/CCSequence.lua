-- @module CCSequence

-----------------------
-- @function [parent=#CCSequence] createWithTwoActions
-- @param  pActionOne
-- @param  pActionTwo

-----------------------
-- @function [parent=#CCSequence] create
-- @param  actions

-----------------------
return nil
