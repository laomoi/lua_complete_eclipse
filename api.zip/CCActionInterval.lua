-- @module CCActionInterval

-----------------------
-- @function [parent=#CCActionInterval] getElapsed
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCActionInterval] setAmplitudeRate
-- @param  self
-- @param  amp

-----------------------
-- @function [parent=#CCActionInterval] getAmplitudeRate
-- @param  self
-- @param  void

-----------------------
return nil
