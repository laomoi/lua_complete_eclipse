-- @module CCActionInterval

-----------------------
-- @function [parent=#CCActionInterval] getElapsed
-- @param  void

-----------------------
-- @function [parent=#CCActionInterval] setAmplitudeRate
-- @param  amp

-----------------------
-- @function [parent=#CCActionInterval] getAmplitudeRate
-- @param  void

-----------------------
return nil
