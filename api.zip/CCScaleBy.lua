-- @module CCScaleBy

-----------------------
-- @function [parent=#CCScaleBy] create
-- @param  duration
-- @param  s

-----------------------
-- @function [parent=#CCScaleBy] create
-- @param  duration
-- @param  sx
-- @param  sy

-----------------------
return nil
