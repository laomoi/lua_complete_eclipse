-- @module CCWaves3D

-----------------------
-- @function [parent=#CCWaves3D] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCWaves3D] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCWaves3D] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCWaves3D] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCWaves3D] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude

-----------------------
return nil
