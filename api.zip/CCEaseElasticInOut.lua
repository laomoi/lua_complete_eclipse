-- @module CCEaseElasticInOut

-----------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param  pAction
-- @param  3

-----------------------
return nil
