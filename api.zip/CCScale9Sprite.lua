-- @module CCScale9Sprite

-----------------------
-- @function [parent=#CCScale9Sprite] getOriginalSize
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] getPreferredSize
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setPreferredSize
-- @param  size

-----------------------
-- @function [parent=#CCScale9Sprite] getCapInsets
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setCapInsets
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] resizableSpriteWithCapInsets
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] create

-----------------------
-- @function [parent=#CCScale9Sprite] setSpriteFrame
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file
-- @param  rect
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file
-- @param  rect

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  capInsets
-- @param  file

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrame
-- @param  spriteFrame
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrame
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrameName
-- @param  spriteFrameName
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrameName
-- @param  spriteFrameName

-----------------------
return nil
