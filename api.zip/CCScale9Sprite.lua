-- @module CCScale9Sprite

-----------------------
-- @function [parent=#CCScale9Sprite] getOriginalSize
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] getPreferredSize
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setPreferredSize
-- @param  self
-- @param  size

-----------------------
-- @function [parent=#CCScale9Sprite] getCapInsets
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setCapInsets
-- @param  self
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCScale9Sprite] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCScale9Sprite] resizableSpriteWithCapInsets
-- @param  self
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] create

-----------------------
-- @function [parent=#CCScale9Sprite] setSpriteFrame
-- @param  self
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file
-- @param  rect
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file
-- @param  rect

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  capInsets
-- @param  file

-----------------------
-- @function [parent=#CCScale9Sprite] create
-- @param  file

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrame
-- @param  spriteFrame
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrame
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrameName
-- @param  spriteFrameName
-- @param  capInsets

-----------------------
-- @function [parent=#CCScale9Sprite] createWithSpriteFrameName
-- @param  spriteFrameName

-----------------------
return nil
