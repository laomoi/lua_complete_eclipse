-- @module CCString

-----------------------
-- @function [parent=#CCString] intValue

-----------------------
-- @function [parent=#CCString] uintValue

-----------------------
-- @function [parent=#CCString] floatValue

-----------------------
-- @function [parent=#CCString] doubleValue

-----------------------
-- @function [parent=#CCString] boolValue

-----------------------
-- @function [parent=#CCString] getCString

-----------------------
-- @function [parent=#CCString] length

-----------------------
-- @function [parent=#CCString] compare
-- @param  str

-----------------------
-- @function [parent=#CCString] isEqual
-- @param  pObject

-----------------------
-- @function [parent=#CCString] create
-- @param  pStr

-----------------------
-- @function [parent=#CCString] createWithData
-- @param  pData
-- @param  nLen

-----------------------
-- @function [parent=#CCString] createWithContentsOfFile
-- @param  pszFileName

-----------------------
return nil
