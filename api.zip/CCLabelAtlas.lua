-- @module CCLabelAtlas

-----------------------
-- @function [parent=#CCLabelAtlas] updateAtlasValues

-----------------------
-- @function [parent=#CCLabelAtlas] setString
-- @param  label

-----------------------
-- @function [parent=#CCLabelAtlas] getString
-- @param  void

-----------------------
-- @function [parent=#CCLabelAtlas] getTexture
-- @param  void

-----------------------
-- @function [parent=#CCLabelAtlas] setTexture
-- @param  texture

-----------------------
-- @function [parent=#CCLabelAtlas] create
-- @param  label
-- @param  charMapFile
-- @param  itemWidth
-- @param  itemHeight
-- @param  startCharMap

-----------------------
-- @function [parent=#CCLabelAtlas] create
-- @param  sring
-- @param  fntFile

-----------------------
return nil
