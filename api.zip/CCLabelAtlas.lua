-- @module CCLabelAtlas

-----------------------
-- @function [parent=#CCLabelAtlas] updateAtlasValues
-- @param  self

-----------------------
-- @function [parent=#CCLabelAtlas] setString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelAtlas] getString
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelAtlas] getTexture
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelAtlas] setTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCLabelAtlas] create
-- @param  label
-- @param  charMapFile
-- @param  itemWidth
-- @param  itemHeight
-- @param  startCharMap

-----------------------
-- @function [parent=#CCLabelAtlas] create
-- @param  sring
-- @param  fntFile

-----------------------
return nil
