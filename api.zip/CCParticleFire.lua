-- @module CCParticleFire

-----------------------
-- @function [parent=#CCParticleFire] create

-----------------------
return nil
