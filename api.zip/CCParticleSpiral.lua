-- @module CCParticleSpiral

-----------------------
-- @function [parent=#CCParticleSpiral] create

-----------------------
return nil
