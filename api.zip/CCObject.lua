-- @module CCObject

-----------------------
-- @function [parent=#CCObject] release
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] retain
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] isSingleReference
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] retainCount
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCObject] isEqual
-- @param  self
-- @param  pObject

-----------------------
-- @function [parent=#CCObject] copy
-- @param  self

-----------------------
-- @function [parent=#CCObject] autorelease
-- @param  self

-----------------------
return nil
