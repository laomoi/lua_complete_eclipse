-- @module CCObject

-----------------------
-- @function [parent=#CCObject] release
-- @param  void

-----------------------
-- @function [parent=#CCObject] retain
-- @param  void

-----------------------
-- @function [parent=#CCObject] isSingleReference
-- @param  void

-----------------------
-- @function [parent=#CCObject] retainCount
-- @param  void

-----------------------
-- @function [parent=#CCObject] isEqual
-- @param  pObject

-----------------------
-- @function [parent=#CCObject] copy

-----------------------
-- @function [parent=#CCObject] autorelease

-----------------------
return nil
