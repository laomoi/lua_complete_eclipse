-- @module CCTwirl

-----------------------
-- @function [parent=#CCTwirl] getPosition
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTwirl] setPosition
-- @param  self
-- @param  position

-----------------------
-- @function [parent=#CCTwirl] getAmplitude
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTwirl] setAmplitude
-- @param  self
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCTwirl] getAmplitudeRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTwirl] setAmplitudeRate
-- @param  self
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCTwirl] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  twirls
-- @param  amplitude

-----------------------
return nil
