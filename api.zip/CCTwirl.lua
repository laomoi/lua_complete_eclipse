-- @module CCTwirl

-----------------------
-- @function [parent=#CCTwirl] getPosition
-- @param  void

-----------------------
-- @function [parent=#CCTwirl] setPosition
-- @param  position

-----------------------
-- @function [parent=#CCTwirl] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCTwirl] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCTwirl] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCTwirl] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCTwirl] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  twirls
-- @param  amplitude

-----------------------
return nil
