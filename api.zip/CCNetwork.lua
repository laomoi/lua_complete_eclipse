-- @module CCNetwork

-----------------------
-- @function [parent=#CCNetwork] isLocalWiFiAvailable
-- @param  void

-----------------------
-- @function [parent=#CCNetwork] isInternetConnectionAvailable
-- @param  void

-----------------------
-- @function [parent=#CCNetwork] isHostNameReachable
-- @param  hostName

-----------------------
-- @function [parent=#CCNetwork] getInternetConnectionStatus
-- @param  void

-----------------------
return nil
