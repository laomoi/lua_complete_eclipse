-- @module CCFollow

-----------------------
-- @function [parent=#CCFollow] isBoundarySet
-- @param  void

-----------------------
-- @function [parent=#CCFollow] setBoudarySet
-- @param  bValue

-----------------------
-- @function [parent=#CCFollow] create
-- @param  pFollowedNode
-- @param  rect

-----------------------
-- @function [parent=#CCFollow] create
-- @param  pFollowedNode

-----------------------
return nil
