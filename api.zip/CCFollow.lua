-- @module CCFollow

-----------------------
-- @function [parent=#CCFollow] isBoundarySet
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCFollow] setBoudarySet
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCFollow] create
-- @param  pFollowedNode
-- @param  rect

-----------------------
-- @function [parent=#CCFollow] create
-- @param  pFollowedNode

-----------------------
return nil
