-- @module CCFadeOutTRTiles

-----------------------
-- @function [parent=#CCFadeOutTRTiles] turnOnTile
-- @param  self
-- @param  pos

-----------------------
-- @function [parent=#CCFadeOutTRTiles] turnOffTile
-- @param  self
-- @param  pos

-----------------------
-- @function [parent=#CCFadeOutTRTiles] transformTile
-- @param  self
-- @param  pos
-- @param  distance

-----------------------
-- @function [parent=#CCFadeOutTRTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
