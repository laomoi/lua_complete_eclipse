-- @module CCFadeOutTRTiles

-----------------------
-- @function [parent=#CCFadeOutTRTiles] turnOnTile
-- @param  pos

-----------------------
-- @function [parent=#CCFadeOutTRTiles] turnOffTile
-- @param  pos

-----------------------
-- @function [parent=#CCFadeOutTRTiles] transformTile
-- @param  pos
-- @param  distance

-----------------------
-- @function [parent=#CCFadeOutTRTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
