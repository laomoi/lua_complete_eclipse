-- @module CCParticleGalaxy

-----------------------
-- @function [parent=#CCParticleGalaxy] create

-----------------------
return nil
