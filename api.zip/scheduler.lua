-- @module scheduler

-----------------------
-- @function [parent=#scheduler] scheduleUpdateGlobal
-- @param  listener
-- @param  isPaused

-----------------------
-- @function [parent=#scheduler] scheduleGlobal
-- @param  listener
-- @param  interval
-- @param  isPaused

-----------------------
-- @function [parent=#scheduler] unscheduleGlobal
-- @param  handle

-----------------------
-- @function [parent=#scheduler] performWithDelayGlobal
-- @param  listener
-- @param  time

-----------------------
return nil
