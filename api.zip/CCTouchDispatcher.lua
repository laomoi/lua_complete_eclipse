-- @module CCTouchDispatcher

-----------------------
-- @function [parent=#CCTouchDispatcher] isDispatchEvents
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTouchDispatcher] setDispatchEvents
-- @param  self
-- @param  bDispatchEvents

-----------------------
return nil
