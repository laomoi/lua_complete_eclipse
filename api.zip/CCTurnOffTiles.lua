-- @module CCTurnOffTiles

-----------------------
-- @function [parent=#CCTurnOffTiles] shuffle
-- @param  self
-- @param  pArray
-- @param  nLen

-----------------------
-- @function [parent=#CCTurnOffTiles] turnOnTile
-- @param  self
-- @param  pos

-----------------------
-- @function [parent=#CCTurnOffTiles] turnOffTile
-- @param  self
-- @param  pos

-----------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param  duration
-- @param  gridSize
-- @param  seed

-----------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
