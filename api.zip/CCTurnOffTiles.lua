-- @module CCTurnOffTiles

-----------------------
-- @function [parent=#CCTurnOffTiles] shuffle
-- @param  pArray
-- @param  nLen

-----------------------
-- @function [parent=#CCTurnOffTiles] turnOnTile
-- @param  pos

-----------------------
-- @function [parent=#CCTurnOffTiles] turnOffTile
-- @param  pos

-----------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param  duration
-- @param  gridSize
-- @param  seed

-----------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
