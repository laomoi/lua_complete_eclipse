-- @module CCRotateBy

-----------------------
-- @function [parent=#CCRotateBy] create
-- @param  duration
-- @param  fDeltaAngle

-----------------------
return nil
