-- @module CCControl

-----------------------
-- @function [parent=#CCControl] getState

-----------------------
-- @function [parent=#CCControl] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCControl] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCControl] setEnabled
-- @param  bEnabled

-----------------------
-- @function [parent=#CCControl] isEnabled

-----------------------
-- @function [parent=#CCControl] setSelected
-- @param  bSelected

-----------------------
-- @function [parent=#CCControl] isSelected

-----------------------
-- @function [parent=#CCControl] setHighlighted
-- @param  bHighlighted

-----------------------
-- @function [parent=#CCControl] isHighlighted

-----------------------
-- @function [parent=#CCControl] hasVisibleParents

-----------------------
-- @function [parent=#CCControl] needsLayout

-----------------------
return nil
