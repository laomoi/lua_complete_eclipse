-- @module CCControl

-----------------------
-- @function [parent=#CCControl] getState
-- @param  self

-----------------------
-- @function [parent=#CCControl] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCControl] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCControl] setEnabled
-- @param  self
-- @param  bEnabled

-----------------------
-- @function [parent=#CCControl] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCControl] setSelected
-- @param  self
-- @param  bSelected

-----------------------
-- @function [parent=#CCControl] isSelected
-- @param  self

-----------------------
-- @function [parent=#CCControl] setHighlighted
-- @param  self
-- @param  bHighlighted

-----------------------
-- @function [parent=#CCControl] isHighlighted
-- @param  self

-----------------------
-- @function [parent=#CCControl] hasVisibleParents
-- @param  self

-----------------------
-- @function [parent=#CCControl] needsLayout
-- @param  self

-----------------------
return nil
