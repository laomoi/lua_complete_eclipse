-- @module CCParallaxNode

-----------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param  child
-- @param  z
-- @param  parallaxRatio
-- @param  positionOffset

-----------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param  child
-- @param  zOrder
-- @param  tag

-----------------------
-- @function [parent=#CCParallaxNode] removeChild
-- @param  child
-- @param  cleanup

-----------------------
-- @function [parent=#CCParallaxNode] removeAllChildrenWithCleanup
-- @param  cleanup

-----------------------
-- @function [parent=#CCParallaxNode] visit
-- @param  void

-----------------------
-- @function [parent=#CCParallaxNode] create

-----------------------
return nil
