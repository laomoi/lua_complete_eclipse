-- @module CCParallaxNode

-----------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param  self
-- @param  child
-- @param  z
-- @param  parallaxRatio
-- @param  positionOffset

-----------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param  self
-- @param  child
-- @param  zOrder
-- @param  tag

-----------------------
-- @function [parent=#CCParallaxNode] removeChild
-- @param  self
-- @param  child
-- @param  cleanup

-----------------------
-- @function [parent=#CCParallaxNode] removeAllChildrenWithCleanup
-- @param  self
-- @param  cleanup

-----------------------
-- @function [parent=#CCParallaxNode] visit
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCParallaxNode] create

-----------------------
return nil
