-- @module CCTMXTilesetInfo

-----------------------
-- @function [parent=#CCTMXTilesetInfo] rectForGID
-- @param  gid

-----------------------
return nil
