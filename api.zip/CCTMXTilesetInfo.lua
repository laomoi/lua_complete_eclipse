-- @module CCTMXTilesetInfo

-----------------------
-- @function [parent=#CCTMXTilesetInfo] rectForGID
-- @param  self
-- @param  gid

-----------------------
return nil
