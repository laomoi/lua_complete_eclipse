-- @module CCTransitionZoomFlipX

-----------------------
-- @function [parent=#CCTransitionZoomFlipX] create
-- @param  t
-- @param  s
-- @param  kCCTransitionOrientationRightOver

-----------------------
return nil
