-- @module CCTransitionFade

-----------------------
-- @function [parent=#CCTransitionFade] create
-- @param  duration
-- @param  scene
-- @param  ccBLACK

-----------------------
return nil
