-- @module CCSceneExtend

-----------------------
-- @field [parent=#CCSceneExtend] __index

-----------------------
-- @function [parent=#CCSceneExtend] extend
-- @param  target

-----------------------
-- @function [parent=#CCSceneExtend] addAutoCleanImage
-- @param  imageName

-----------------------
return nil
