-- @module instead

-----------------------
-- @function [parent=#instead] ccBezierConfig
-- @param  void

-----------------------
return nil
