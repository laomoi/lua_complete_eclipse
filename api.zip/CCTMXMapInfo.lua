-- @module CCTMXMapInfo

-----------------------
-- @function [parent=#CCTMXMapInfo] setOrientation
-- @param  val

-----------------------
-- @function [parent=#CCTMXMapInfo] getOrientation

-----------------------
-- @function [parent=#CCTMXMapInfo] setMapSize
-- @param  sz

-----------------------
-- @function [parent=#CCTMXMapInfo] getMapSize

-----------------------
-- @function [parent=#CCTMXMapInfo] setTileSize
-- @param  sz

-----------------------
-- @function [parent=#CCTMXMapInfo] getTileSize

-----------------------
-- @function [parent=#CCTMXMapInfo] setLayers
-- @param  pval

-----------------------
-- @function [parent=#CCTMXMapInfo] getLayers

-----------------------
-- @function [parent=#CCTMXMapInfo] setTilesets
-- @param  pval

-----------------------
-- @function [parent=#CCTMXMapInfo] getTilesets

-----------------------
-- @function [parent=#CCTMXMapInfo] setObjectGroups
-- @param  val

-----------------------
-- @function [parent=#CCTMXMapInfo] getObjectGroups

-----------------------
-- @function [parent=#CCTMXMapInfo] setParentElement
-- @param  val

-----------------------
-- @function [parent=#CCTMXMapInfo] getParentElement

-----------------------
-- @function [parent=#CCTMXMapInfo] setParentGID
-- @param  val

-----------------------
-- @function [parent=#CCTMXMapInfo] getParentGID

-----------------------
-- @function [parent=#CCTMXMapInfo] setLayerAttribs
-- @param  val

-----------------------
-- @function [parent=#CCTMXMapInfo] getLayerAttribs

-----------------------
-- @function [parent=#CCTMXMapInfo] setStoringCharacters
-- @param  val

-----------------------
-- @function [parent=#CCTMXMapInfo] getStoringCharacters

-----------------------
-- @function [parent=#CCTMXMapInfo] setProperties
-- @param  pval

-----------------------
-- @function [parent=#CCTMXMapInfo] getProperties

-----------------------
-- @function [parent=#CCTMXMapInfo] setTileProperties
-- @param  tileProperties

-----------------------
-- @function [parent=#CCTMXMapInfo] getTileProperties

-----------------------
-- @function [parent=#CCTMXMapInfo] setCurrentString
-- @param  currentString

-----------------------
-- @function [parent=#CCTMXMapInfo] getCurrentString

-----------------------
-- @function [parent=#CCTMXMapInfo] setTMXFileName
-- @param  fileName

-----------------------
-- @function [parent=#CCTMXMapInfo] getTMXFileName

-----------------------
-- @function [parent=#CCTMXMapInfo] startElement
-- @param  ctx
-- @param  name
-- @param  atts

-----------------------
-- @function [parent=#CCTMXMapInfo] endElement
-- @param  ctx
-- @param  name

-----------------------
-- @function [parent=#CCTMXMapInfo] textHandler
-- @param  ctx
-- @param  ch
-- @param  len

-----------------------
-- @function [parent=#CCTMXMapInfo] parseXMLFile
-- @param  xmlFilename

-----------------------
-- @function [parent=#CCTMXMapInfo] parseXMLString
-- @param  xmlString

-----------------------
-- @function [parent=#CCTMXMapInfo] formatWithTMXFile
-- @param  tmxFile

-----------------------
-- @function [parent=#CCTMXMapInfo] formatWithXML
-- @param  tmxString
-- @param  resourcePath

-----------------------
return nil
