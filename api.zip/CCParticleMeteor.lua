-- @module CCParticleMeteor

-----------------------
-- @function [parent=#CCParticleMeteor] create

-----------------------
return nil
