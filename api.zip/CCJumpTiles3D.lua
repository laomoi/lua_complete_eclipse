-- @module CCJumpTiles3D

-----------------------
-- @function [parent=#CCJumpTiles3D] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCJumpTiles3D] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCJumpTiles3D] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCJumpTiles3D] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCJumpTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  numberOfJumps
-- @param  amplitude

-----------------------
return nil
