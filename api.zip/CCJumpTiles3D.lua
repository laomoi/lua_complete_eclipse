-- @module CCJumpTiles3D

-----------------------
-- @function [parent=#CCJumpTiles3D] getAmplitude
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCJumpTiles3D] setAmplitude
-- @param  self
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCJumpTiles3D] getAmplitudeRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCJumpTiles3D] setAmplitudeRate
-- @param  self
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCJumpTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  numberOfJumps
-- @param  amplitude

-----------------------
return nil
