-- @module CCShapeNode

-----------------------
-- @function [parent=#CCShapeNode] getColor
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setColor
-- @param  color

-----------------------
-- @function [parent=#CCShapeNode] getLineWidth
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setLineWidth
-- @param  lineWidth

-----------------------
-- @function [parent=#CCShapeNode] getLineStipple
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setLineStipple
-- @param  pattern

-----------------------
-- @function [parent=#CCShapeNode] isLineStippleEnabled
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setLineStippleEnabled
-- @param  lineStippleEnabled

-----------------------
return nil
