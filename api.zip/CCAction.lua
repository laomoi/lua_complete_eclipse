-- @module CCAction

-----------------------
-- @function [parent=#CCAction] isDone
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAction] getTarget
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAction] getOriginalTarget
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAction] getTag
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAction] setTag
-- @param  self
-- @param  nTag

-----------------------
return nil
