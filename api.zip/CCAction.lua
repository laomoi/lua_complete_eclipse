-- @module CCAction

-----------------------
-- @function [parent=#CCAction] isDone
-- @param  void

-----------------------
-- @function [parent=#CCAction] getTarget
-- @param  void

-----------------------
-- @function [parent=#CCAction] getOriginalTarget
-- @param  void

-----------------------
-- @function [parent=#CCAction] getTag
-- @param  void

-----------------------
-- @function [parent=#CCAction] setTag
-- @param  nTag

-----------------------
return nil
