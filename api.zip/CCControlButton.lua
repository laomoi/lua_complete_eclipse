-- @module CCControlButton

-----------------------
-- @function [parent=#CCControlButton] doesAdjustBackgroundImage

-----------------------
-- @function [parent=#CCControlButton] setAdjustBackgroundImage
-- @param  adjustBackgroundImage

-----------------------
-- @function [parent=#CCControlButton] getTitleLabel
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] setTitleLabel
-- @param  titleLabel

-----------------------
-- @function [parent=#CCControlButton] getBackgroundSprite
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] setBackgroundSprite
-- @param  backgroundSprite

-----------------------
-- @function [parent=#CCControlButton] getPreferredSize
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] setPreferredSize
-- @param  size

-----------------------
-- @function [parent=#CCControlButton] getZoomOnTouchDown
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] setZoomOnTouchDown
-- @param  zoom

-----------------------
-- @function [parent=#CCControlButton] getLabelAnchorPoint
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] setLabelAnchorPoint
-- @param  point

-----------------------
-- @function [parent=#CCControlButton] isPushed
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] getVerticalMargin
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] getHorizontalOrigin
-- @param  void

-----------------------
-- @function [parent=#CCControlButton] setMargins
-- @param  marginH
-- @param  marginV

-----------------------
-- @function [parent=#CCControlButton] create
-- @param  label
-- @param  backgroundSprite

-----------------------
-- @function [parent=#CCControlButton] create
-- @param  title
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCControlButton] create
-- @param  sprite

-----------------------
-- @function [parent=#CCControlButton] create

-----------------------
-- @function [parent=#CCControlButton] getTitleForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleForState
-- @param  title
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleColorForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleColorForState
-- @param  color
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleLabelForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleLabelForState
-- @param  label
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleTTFForState
-- @param  fntFile
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleTTFForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleTTFSizeForState
-- @param  size
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleTTFSizeForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setTitleBMFontForState
-- @param  fntFile
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getTitleBMFontForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] getBackgroundSpriteForState
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setBackgroundSpriteForState
-- @param  sprite
-- @param  state

-----------------------
-- @function [parent=#CCControlButton] setBackgroundSpriteFrameForState
-- @param  spriteFrame
-- @param  state

-----------------------
return nil
