-- @module CCFadeOut

-----------------------
-- @function [parent=#CCFadeOut] create
-- @param  d

-----------------------
return nil
