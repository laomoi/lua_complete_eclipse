-- @module CCAtlasNode

-----------------------
-- @function [parent=#CCAtlasNode] getTextureAtlas
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] setTextureAtlas
-- @param  self
-- @param  atlas

-----------------------
-- @function [parent=#CCAtlasNode] getTexture
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAtlasNode] setTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCAtlasNode] getColor
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCAtlasNode] getQuadsToDraw
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] setQuadsToDraw
-- @param  self
-- @param  quadsToDraw

-----------------------
-- @function [parent=#CCAtlasNode] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCAtlasNode] updateAtlasValues
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] isOpacityModifyRGB
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] setOpacityModifyRGB
-- @param  self
-- @param  isOpacityModifyRGB

-----------------------
-- @function [parent=#CCAtlasNode] create
-- @param  tile
-- @param  tileWidth
-- @param  tileHeight
-- @param  itemsToRender

-----------------------
return nil
