-- @module CCAtlasNode

-----------------------
-- @function [parent=#CCAtlasNode] getTextureAtlas

-----------------------
-- @function [parent=#CCAtlasNode] setTextureAtlas
-- @param  atlas

-----------------------
-- @function [parent=#CCAtlasNode] getTexture
-- @param  void

-----------------------
-- @function [parent=#CCAtlasNode] setTexture
-- @param  texture

-----------------------
-- @function [parent=#CCAtlasNode] getColor

-----------------------
-- @function [parent=#CCAtlasNode] setColor
-- @param  color

-----------------------
-- @function [parent=#CCAtlasNode] getQuadsToDraw

-----------------------
-- @function [parent=#CCAtlasNode] setQuadsToDraw
-- @param  quadsToDraw

-----------------------
-- @function [parent=#CCAtlasNode] getOpacity

-----------------------
-- @function [parent=#CCAtlasNode] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCAtlasNode] updateAtlasValues

-----------------------
-- @function [parent=#CCAtlasNode] isOpacityModifyRGB

-----------------------
-- @function [parent=#CCAtlasNode] setOpacityModifyRGB
-- @param  isOpacityModifyRGB

-----------------------
-- @function [parent=#CCAtlasNode] create
-- @param  tile
-- @param  tileWidth
-- @param  tileHeight
-- @param  itemsToRender

-----------------------
return nil
