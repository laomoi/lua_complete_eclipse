-- @module CCBezierBy

-----------------------
-- @function [parent=#CCBezierBy] create
-- @param  t
-- @param  c

-----------------------
return nil
