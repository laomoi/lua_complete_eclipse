-- @module luaoc

-----------------------
-- @function [parent=#luaoc] callStaticMethod
-- @param  className
-- @param  methodName
-- @param  args

-----------------------
return nil
