-- @module CCHTTPRequest

-----------------------
-- @function [parent=#CCHTTPRequest] setRequestUrl
-- @param  url

-----------------------
-- @function [parent=#CCHTTPRequest] addRequestHeader
-- @param  header

-----------------------
-- @function [parent=#CCHTTPRequest] addPOSTValue
-- @param  key
-- @param  value

-----------------------
-- @function [parent=#CCHTTPRequest] setPOSTData
-- @param  data

-----------------------
-- @function [parent=#CCHTTPRequest] setAcceptEncoding
-- @param  acceptEncoding

-----------------------
-- @function [parent=#CCHTTPRequest] setTimeout
-- @param  timeout

-----------------------
-- @function [parent=#CCHTTPRequest] start
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] cancel
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] getState
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] getResponseStatusCode
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] getResponseString
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] getResponseDataLua
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] getResponseDataLength
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] saveResponseData
-- @param  filename

-----------------------
-- @function [parent=#CCHTTPRequest] getErrorCode
-- @param  void

-----------------------
-- @function [parent=#CCHTTPRequest] getErrorMessage
-- @param  void

-----------------------
return nil
