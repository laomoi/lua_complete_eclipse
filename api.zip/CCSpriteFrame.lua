-- @module CCSpriteFrame

-----------------------
-- @function [parent=#CCSpriteFrame] getRectInPixels
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setRectInPixels
-- @param  rectInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] isRotated
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setRotated
-- @param  bRotated

-----------------------
-- @function [parent=#CCSpriteFrame] getRect
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setRect
-- @param  rect

-----------------------
-- @function [parent=#CCSpriteFrame] getOffsetInPixels
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setOffsetInPixels
-- @param  offsetInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] getOriginalSizeInPixels
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setOriginalSizeInPixels
-- @param  sizeInPixels

-----------------------
-- @function [parent=#CCSpriteFrame] getOriginalSize

-----------------------
-- @function [parent=#CCSpriteFrame] setOriginalSize
-- @param  size

-----------------------
-- @function [parent=#CCSpriteFrame] getTexture
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrame] setTexture
-- @param  pobTexture

-----------------------
-- @function [parent=#CCSpriteFrame] getOffset

-----------------------
-- @function [parent=#CCSpriteFrame] setOffset
-- @param  offsets

-----------------------
-- @function [parent=#CCSpriteFrame] create
-- @param  filename
-- @param  rect
-- @param  rotated
-- @param  offset
-- @param  originalSize

-----------------------
-- @function [parent=#CCSpriteFrame] create
-- @param  filename
-- @param  rect

-----------------------
-- @function [parent=#CCSpriteFrame] createWithTexture
-- @param  pobTexture
-- @param  rect
-- @param  rotated
-- @param  offset
-- @param  originalSize

-----------------------
-- @function [parent=#CCSpriteFrame] createWithTexture
-- @param  pobTexture
-- @param  rect

-----------------------
return nil
