-- @module CCCamera

-----------------------
-- @function [parent=#CCCamera] description
-- @param  void

-----------------------
-- @function [parent=#CCCamera] setDirty
-- @param  bValue

-----------------------
-- @function [parent=#CCCamera] isDirty
-- @param  void

-----------------------
-- @function [parent=#CCCamera] restore
-- @param  void

-----------------------
-- @function [parent=#CCCamera] locate
-- @param  void

-----------------------
-- @function [parent=#CCCamera] setEyeXYZ
-- @param  fEyeX
-- @param  fEyeY
-- @param  fEyeZ

-----------------------
-- @function [parent=#CCCamera] setCenterXYZ
-- @param  fCenterX
-- @param  fCenterY
-- @param  fCenterZ

-----------------------
-- @function [parent=#CCCamera] setUpXYZ
-- @param  fUpX
-- @param  fUpY
-- @param  fUpZ

-----------------------
-- @function [parent=#CCCamera] getEyeXYZ
-- @param  pEyeX
-- @param  pEyeY
-- @param  pEyeZ

-----------------------
-- @function [parent=#CCCamera] getCenterXYZ
-- @param  pCenterX
-- @param  pCenterY
-- @param  pCenterZ

-----------------------
-- @function [parent=#CCCamera] getUpXYZ
-- @param  pUpX
-- @param  pUpY
-- @param  pUpZ

-----------------------
-- @function [parent=#CCCamera] getZEye

-----------------------
return nil
