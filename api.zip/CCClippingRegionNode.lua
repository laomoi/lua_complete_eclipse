-- @module CCClippingRegionNode

-----------------------
-- @function [parent=#CCClippingRegionNode] create
-- @param  clippingRegion

-----------------------
-- @function [parent=#CCClippingRegionNode] create
-- @param  void

-----------------------
-- @function [parent=#CCClippingRegionNode] getClippingRegion
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCClippingRegionNode] setClippingRegion
-- @param  self
-- @param  clippingRegion

-----------------------
-- @function [parent=#CCClippingRegionNode] isClippingEnabled
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCClippingRegionNode] setClippingEnabled
-- @param  self
-- @param  enabled

-----------------------
return nil
