-- @module CCTargetedAction

-----------------------
-- @function [parent=#CCTargetedAction] getForcedTarget
-- @param  void

-----------------------
-- @function [parent=#CCTargetedAction] setForcedTarget
-- @param  target

-----------------------
-- @function [parent=#CCTargetedAction] create
-- @param  pTarget
-- @param  pAction

-----------------------
return nil
