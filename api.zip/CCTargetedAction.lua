-- @module CCTargetedAction

-----------------------
-- @function [parent=#CCTargetedAction] getForcedTarget
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTargetedAction] setForcedTarget
-- @param  self
-- @param  target

-----------------------
-- @function [parent=#CCTargetedAction] create
-- @param  pTarget
-- @param  pAction

-----------------------
return nil
