-- @module CCTileMapAtlas

-----------------------
-- @function [parent=#CCTileMapAtlas] getTGAInfo

-----------------------
-- @function [parent=#CCTileMapAtlas] setTGAInfo
-- @param  val

-----------------------
-- @function [parent=#CCTileMapAtlas] setTile
-- @param  tile
-- @param  position

-----------------------
-- @function [parent=#CCTileMapAtlas] releaseMap

-----------------------
-- @function [parent=#CCTileMapAtlas] tileAt
-- @param  pos

-----------------------
-- @function [parent=#CCTileMapAtlas] create
-- @param  tile
-- @param  mapFile
-- @param  tileWidth
-- @param  tileHeight

-----------------------
return nil
