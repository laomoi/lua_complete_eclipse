-- @module CCRibbon

-----------------------
-- @function [parent=#CCRibbon] setTexture
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getTexture

-----------------------
-- @function [parent=#CCRibbon] setTextureLength
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getTextureLength

-----------------------
-- @function [parent=#CCRibbon] setBlendFunc
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getBlendFunc

-----------------------
-- @function [parent=#CCRibbon] setColor
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getColor

-----------------------
-- @function [parent=#CCRibbon] addPointAt
-- @param  location
-- @param  width

-----------------------
-- @function [parent=#CCRibbon] sideOfLine
-- @param  p
-- @param  l1
-- @param  l2

-----------------------
-- @function [parent=#CCRibbon] create
-- @param  w
-- @param  path
-- @param  length
-- @param  color
-- @param  fade

-----------------------
return nil
