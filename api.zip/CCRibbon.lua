-- @module CCRibbon

-----------------------
-- @function [parent=#CCRibbon] setTexture
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getTexture
-- @param  self

-----------------------
-- @function [parent=#CCRibbon] setTextureLength
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getTextureLength
-- @param  self

-----------------------
-- @function [parent=#CCRibbon] setBlendFunc
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getBlendFunc
-- @param  self

-----------------------
-- @function [parent=#CCRibbon] setColor
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCRibbon] getColor
-- @param  self

-----------------------
-- @function [parent=#CCRibbon] addPointAt
-- @param  self
-- @param  location
-- @param  width

-----------------------
-- @function [parent=#CCRibbon] sideOfLine
-- @param  self
-- @param  p
-- @param  l1
-- @param  l2

-----------------------
-- @function [parent=#CCRibbon] create
-- @param  w
-- @param  path
-- @param  length
-- @param  color
-- @param  fade

-----------------------
return nil
