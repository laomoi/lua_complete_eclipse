-- @module CCLabelTTF

-----------------------
-- @function [parent=#CCLabelTTF] setString
-- @param  label

-----------------------
-- @function [parent=#CCLabelTTF] getString
-- @param  void

-----------------------
-- @function [parent=#CCLabelTTF] getHorizontalAlignment

-----------------------
-- @function [parent=#CCLabelTTF] setHorizontalAlignment
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelTTF] getVerticalAlignment

-----------------------
-- @function [parent=#CCLabelTTF] setVerticalAlignment
-- @param  verticalAlignment

-----------------------
-- @function [parent=#CCLabelTTF] getDimensions

-----------------------
-- @function [parent=#CCLabelTTF] setDimensions
-- @param  dim

-----------------------
-- @function [parent=#CCLabelTTF] getFontSize

-----------------------
-- @function [parent=#CCLabelTTF] setFontSize
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] getFontName

-----------------------
-- @function [parent=#CCLabelTTF] setFontName
-- @param  fontName

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  str
-- @param  fontName
-- @param  fontSize
-- @param  dimensions
-- @param  hAlignment
-- @param  vAlignment

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  str
-- @param  fontName
-- @param  fontSize
-- @param  dimensions
-- @param  hAlignment

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  str
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] create

-----------------------
return nil
