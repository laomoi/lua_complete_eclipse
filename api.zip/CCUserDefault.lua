-- @module CCUserDefault

-----------------------
-- @function [parent=#CCUserDefault] getBoolForKey
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getIntegerForKey
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getFloatForKey
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getDoubleForKey
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] getStringForKey
-- @param  pKey

-----------------------
-- @function [parent=#CCUserDefault] setBoolForKey
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setIntegerForKey
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setFloatForKey
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setDoubleForKey
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] setStringForKey
-- @param  pKey
-- @param  value

-----------------------
-- @function [parent=#CCUserDefault] flush

-----------------------
-- @function [parent=#CCUserDefault] sharedUserDefault

-----------------------
-- @function [parent=#CCUserDefault] purgeSharedUserDefault

-----------------------
-- @function [parent=#CCUserDefault] getXMLFilePath

-----------------------
return nil
