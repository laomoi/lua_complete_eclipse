-- @module CCCardinalSplineTo

-----------------------
-- @function [parent=#CCCardinalSplineTo] getPoints

-----------------------
-- @function [parent=#CCCardinalSplineTo] setPoints
-- @param  points

-----------------------
-- @function [parent=#CCCardinalSplineTo] create
-- @param  duration
-- @param  points
-- @param  tension

-----------------------
return nil
