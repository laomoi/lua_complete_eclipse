-- @module CCCardinalSplineTo

-----------------------
-- @function [parent=#CCCardinalSplineTo] getPoints
-- @param  self

-----------------------
-- @function [parent=#CCCardinalSplineTo] setPoints
-- @param  self
-- @param  points

-----------------------
-- @function [parent=#CCCardinalSplineTo] create
-- @param  duration
-- @param  points
-- @param  tension

-----------------------
return nil
