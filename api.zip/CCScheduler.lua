-- @module CCScheduler

-----------------------
-- @function [parent=#CCScheduler] getTimeScale
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCScheduler] setTimeScale
-- @param  self
-- @param  fTimeScale

-----------------------
-- @function [parent=#CCScheduler] scheduleScriptFunc
-- @param  self
-- @param  funcID
-- @param  fInterval
-- @param  bPaused

-----------------------
-- @function [parent=#CCScheduler] unscheduleScriptEntry
-- @param  self
-- @param  uScheduleScriptEntryID

-----------------------
return nil
