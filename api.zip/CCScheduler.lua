-- @module CCScheduler

-----------------------
-- @function [parent=#CCScheduler] getTimeScale
-- @param  void

-----------------------
-- @function [parent=#CCScheduler] setTimeScale
-- @param  fTimeScale

-----------------------
-- @function [parent=#CCScheduler] scheduleScriptFunc
-- @param  funcID
-- @param  fInterval
-- @param  bPaused

-----------------------
-- @function [parent=#CCScheduler] unscheduleScriptEntry
-- @param  uScheduleScriptEntryID

-----------------------
return nil
