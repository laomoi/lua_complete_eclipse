-- @module CCDictionary

-----------------------
-- @function [parent=#CCDictionary] count
-- @param  self

-----------------------
-- @function [parent=#CCDictionary] allKeys
-- @param  self

-----------------------
-- @function [parent=#CCDictionary] allKeysForObject
-- @param  self
-- @param  object

-----------------------
-- @function [parent=#CCDictionary] objectForKey
-- @param  self
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] objectForKey
-- @param  self
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] valueForKey
-- @param  self
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] valueForKey
-- @param  self
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] setObject
-- @param  self
-- @param  pObject
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] setObject
-- @param  self
-- @param  pObject
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] removeObjectForKey
-- @param  self
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] removeObjectForKey
-- @param  self
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] removeObjectsForKeys
-- @param  self
-- @param  pKeyArray

-----------------------
-- @function [parent=#CCDictionary] removeAllObjects
-- @param  self

-----------------------
-- @function [parent=#CCDictionary] create

-----------------------
-- @function [parent=#CCDictionary] createWithDictionary
-- @param  srcDict

-----------------------
-- @function [parent=#CCDictionary] createWithContentsOfFile
-- @param  pFileName

-----------------------
return nil
