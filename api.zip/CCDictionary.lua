-- @module CCDictionary

-----------------------
-- @function [parent=#CCDictionary] count

-----------------------
-- @function [parent=#CCDictionary] allKeys

-----------------------
-- @function [parent=#CCDictionary] allKeysForObject
-- @param  object

-----------------------
-- @function [parent=#CCDictionary] objectForKey
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] objectForKey
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] valueForKey
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] valueForKey
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] setObject
-- @param  pObject
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] setObject
-- @param  pObject
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] removeObjectForKey
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] removeObjectForKey
-- @param  key

-----------------------
-- @function [parent=#CCDictionary] removeObjectsForKeys
-- @param  pKeyArray

-----------------------
-- @function [parent=#CCDictionary] removeAllObjects

-----------------------
-- @function [parent=#CCDictionary] create

-----------------------
-- @function [parent=#CCDictionary] createWithDictionary
-- @param  srcDict

-----------------------
-- @function [parent=#CCDictionary] createWithContentsOfFile
-- @param  pFileName

-----------------------
return nil
