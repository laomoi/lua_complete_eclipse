-- @module CCRipple3D

-----------------------
-- @function [parent=#CCRipple3D] getPosition
-- @param  void

-----------------------
-- @function [parent=#CCRipple3D] setPosition
-- @param  position

-----------------------
-- @function [parent=#CCRipple3D] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCRipple3D] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCRipple3D] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCRipple3D] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCRipple3D] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  radius
-- @param  waves
-- @param  amplitude

-----------------------
return nil
