-- @module CCShow

-----------------------
-- @function [parent=#CCShow] create

-----------------------
return nil
