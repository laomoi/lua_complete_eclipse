-- @module SimpleAudioEngine

-----------------------
-- @function [parent=#SimpleAudioEngine] sharedEngine

-----------------------
-- @function [parent=#SimpleAudioEngine] preloadBackgroundMusic
-- @param  pszFilePath

-----------------------
-- @function [parent=#SimpleAudioEngine] playBackgroundMusic
-- @param  pszFilePath
-- @param  false

-----------------------
-- @function [parent=#SimpleAudioEngine] stopBackgroundMusic
-- @param  false

-----------------------
-- @function [parent=#SimpleAudioEngine] pauseBackgroundMusic

-----------------------
-- @function [parent=#SimpleAudioEngine] resumeBackgroundMusic

-----------------------
-- @function [parent=#SimpleAudioEngine] rewindBackgroundMusic

-----------------------
-- @function [parent=#SimpleAudioEngine] willPlayBackgroundMusic

-----------------------
-- @function [parent=#SimpleAudioEngine] isBackgroundMusicPlaying

-----------------------
-- @function [parent=#SimpleAudioEngine] playEffect
-- @param  pszFilePath
-- @param  false

-----------------------
-- @function [parent=#SimpleAudioEngine] stopEffect
-- @param  nSoundId

-----------------------
-- @function [parent=#SimpleAudioEngine] preloadEffect
-- @param  pszFilePath

-----------------------
-- @function [parent=#SimpleAudioEngine] unloadEffect
-- @param  pszFilePath

-----------------------
-- @function [parent=#SimpleAudioEngine] getBackgroundMusicVolume

-----------------------
-- @function [parent=#SimpleAudioEngine] setBackgroundMusicVolume
-- @param  volume

-----------------------
-- @function [parent=#SimpleAudioEngine] getEffectsVolume

-----------------------
-- @function [parent=#SimpleAudioEngine] setEffectsVolume
-- @param  volume

-----------------------
return nil
