-- @module CCTMXLayerInfo

-----------------------
-- @function [parent=#CCTMXLayerInfo] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayerInfo] setProperties
-- @param  self
-- @param  pval

-----------------------
return nil
