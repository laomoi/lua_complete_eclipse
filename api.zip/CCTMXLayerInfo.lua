-- @module CCTMXLayerInfo

-----------------------
-- @function [parent=#CCTMXLayerInfo] getProperties

-----------------------
-- @function [parent=#CCTMXLayerInfo] setProperties
-- @param  pval

-----------------------
return nil
