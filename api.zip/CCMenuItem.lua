-- @module CCMenuItem

-----------------------
-- @function [parent=#CCMenuItem] rect
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] activate
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] selected
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] unselected
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] setEnabled
-- @param  self
-- @param  enabled

-----------------------
-- @function [parent=#CCMenuItem] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] isSelected
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] registerScriptTapHandler
-- @param  self
-- @param  funcID

-----------------------
-- @function [parent=#CCMenuItem] unregisterScriptTapHandler
-- @param  self
-- @param  void

-----------------------
return nil
