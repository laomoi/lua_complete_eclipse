-- @module CCMenuItem

-----------------------
-- @function [parent=#CCMenuItem] rect

-----------------------
-- @function [parent=#CCMenuItem] activate

-----------------------
-- @function [parent=#CCMenuItem] selected

-----------------------
-- @function [parent=#CCMenuItem] unselected

-----------------------
-- @function [parent=#CCMenuItem] setEnabled
-- @param  enabled

-----------------------
-- @function [parent=#CCMenuItem] isEnabled

-----------------------
-- @function [parent=#CCMenuItem] isSelected

-----------------------
-- @function [parent=#CCMenuItem] registerScriptTapHandler
-- @param  funcID

-----------------------
-- @function [parent=#CCMenuItem] unregisterScriptTapHandler
-- @param  void

-----------------------
return nil
