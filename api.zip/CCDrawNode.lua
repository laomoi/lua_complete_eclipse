-- @module CCDrawNode

-----------------------
-- @function [parent=#CCDrawNode] create

-----------------------
-- @function [parent=#CCDrawNode] drawDot
-- @param  pos
-- @param  radius
-- @param  color

-----------------------
-- @function [parent=#CCDrawNode] drawSegment
-- @param  from
-- @param  to
-- @param  radius
-- @param  color

-----------------------
-- @function [parent=#CCDrawNode] drawPolygon
-- @param  verts
-- @param  fillColor
-- @param  borderWidth
-- @param  borderColor

-----------------------
-- @function [parent=#CCDrawNode] clear

-----------------------
-- @function [parent=#CCDrawNode] getBlendFunc

-----------------------
-- @function [parent=#CCDrawNode] setBlendFunc
-- @param  blendFunc

-----------------------
return nil
