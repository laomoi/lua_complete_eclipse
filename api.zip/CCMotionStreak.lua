-- @module CCMotionStreak

-----------------------
-- @function [parent=#CCMotionStreak] create
-- @param  fade
-- @param  minSeg
-- @param  stroke
-- @param  color
-- @param  path

-----------------------
-- @function [parent=#CCMotionStreak] create
-- @param  fade
-- @param  minSeg
-- @param  stroke
-- @param  color
-- @param  texture

-----------------------
-- @function [parent=#CCMotionStreak] tintWithColor
-- @param  self
-- @param  colors

-----------------------
-- @function [parent=#CCMotionStreak] reset
-- @param  self

-----------------------
-- @function [parent=#CCMotionStreak] setPosition
-- @param  self
-- @param  position

-----------------------
-- @function [parent=#CCMotionStreak] getTexture
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] setTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCMotionStreak] setBlendFunc
-- @param  self
-- @param  blendFunc

-----------------------
-- @function [parent=#CCMotionStreak] getBlendFunc
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMotionStreak] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCMotionStreak] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCMotionStreak] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] isFastMode
-- @param  self

-----------------------
-- @function [parent=#CCMotionStreak] setFastMode
-- @param  self
-- @param  bFastMode

-----------------------
-- @function [parent=#CCMotionStreak] isStartingPositionInitialized
-- @param  self

-----------------------
-- @function [parent=#CCMotionStreak] setStartingPositionInitialized
-- @param  self
-- @param  bStartingPositionInitialized

-----------------------
return nil
