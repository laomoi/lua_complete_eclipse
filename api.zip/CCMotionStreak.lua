-- @module CCMotionStreak

-----------------------
-- @function [parent=#CCMotionStreak] create
-- @param  fade
-- @param  minSeg
-- @param  stroke
-- @param  color
-- @param  path

-----------------------
-- @function [parent=#CCMotionStreak] create
-- @param  fade
-- @param  minSeg
-- @param  stroke
-- @param  color
-- @param  texture

-----------------------
-- @function [parent=#CCMotionStreak] tintWithColor
-- @param  colors

-----------------------
-- @function [parent=#CCMotionStreak] reset

-----------------------
-- @function [parent=#CCMotionStreak] setPosition
-- @param  position

-----------------------
-- @function [parent=#CCMotionStreak] getTexture
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] setTexture
-- @param  texture

-----------------------
-- @function [parent=#CCMotionStreak] setBlendFunc
-- @param  blendFunc

-----------------------
-- @function [parent=#CCMotionStreak] getBlendFunc
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] setColor
-- @param  color

-----------------------
-- @function [parent=#CCMotionStreak] getColor
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCMotionStreak] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCMotionStreak] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCMotionStreak] isFastMode

-----------------------
-- @function [parent=#CCMotionStreak] setFastMode
-- @param  bFastMode

-----------------------
-- @function [parent=#CCMotionStreak] isStartingPositionInitialized

-----------------------
-- @function [parent=#CCMotionStreak] setStartingPositionInitialized
-- @param  bStartingPositionInitialized

-----------------------
return nil
