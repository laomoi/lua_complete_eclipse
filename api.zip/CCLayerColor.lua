-- @module CCLayerColor

-----------------------
-- @function [parent=#CCLayerColor] changeWidth
-- @param  w

-----------------------
-- @function [parent=#CCLayerColor] changeHeight
-- @param  h

-----------------------
-- @function [parent=#CCLayerColor] changeWidthAndHeight
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCLayerColor] setContentSize
-- @param  var

-----------------------
-- @function [parent=#CCLayerColor] setOpacity
-- @param  var

-----------------------
-- @function [parent=#CCLayerColor] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] setColor
-- @param  Value

-----------------------
-- @function [parent=#CCLayerColor] getColor
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] setBlendFunc
-- @param  Value

-----------------------
-- @function [parent=#CCLayerColor] getBlendFunc
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCLayerColor] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCLayerColor] create
-- @param  color
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCLayerColor] create
-- @param  color

-----------------------
return nil
