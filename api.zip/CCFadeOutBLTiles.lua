-- @module CCFadeOutBLTiles

-----------------------
-- @function [parent=#CCFadeOutBLTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
