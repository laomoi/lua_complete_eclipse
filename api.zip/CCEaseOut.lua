-- @module CCEaseOut

-----------------------
-- @function [parent=#CCEaseOut] create
-- @param  pAction
-- @param  fRate

-----------------------
return nil
