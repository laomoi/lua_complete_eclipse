-- @module CCEditBox

-----------------------
-- @function [parent=#CCEditBox] create
-- @param  size
-- @param  pNormal9SpriteBg
-- @param  NULL
-- @param  NULL

-----------------------
-- @function [parent=#CCEditBox] onExit

-----------------------
-- @function [parent=#CCEditBox] editboxEventHandler
-- @param  eventType

-----------------------
-- @function [parent=#CCEditBox] create
-- @param  create

-----------------------
-- @function [parent=#CCEditBox] create
-- @param  create

-----------------------
-- @function [parent=#CCEditBox] registerScriptEditBoxHandler
-- @param  editboxEventHandler

-----------------------
-- @function [parent=#CCEditBox] registerScriptEditBoxHandler
-- @param  handler

-----------------------
-- @function [parent=#CCEditBox] unregisterScriptEditBoxHandler
-- @param  void

-----------------------
-- @function [parent=#CCEditBox] setText
-- @param  pText

-----------------------
-- @function [parent=#CCEditBox] getText
-- @param  void

-----------------------
-- @function [parent=#CCEditBox] setFontColor
-- @param  color

-----------------------
-- @function [parent=#CCEditBox] setPlaceholderFontColor
-- @param  color

-----------------------
-- @function [parent=#CCEditBox] setPlaceHolder
-- @param  pText

-----------------------
-- @function [parent=#CCEditBox] getPlaceHolder
-- @param  void

-----------------------
-- @function [parent=#CCEditBox] setInputMode
-- @param  inputMode

-----------------------
-- @function [parent=#CCEditBox] setMaxLength
-- @param  maxLength

-----------------------
-- @function [parent=#CCEditBox] getMaxLength

-----------------------
-- @function [parent=#CCEditBox] setInputFlag
-- @param  inputFlag

-----------------------
-- @function [parent=#CCEditBox] setReturnType
-- @param  returnType

-----------------------
return nil
