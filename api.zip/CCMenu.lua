-- @module CCMenu

-----------------------
-- @function [parent=#CCMenu] alignItemsVertically

-----------------------
-- @function [parent=#CCMenu] alignItemsVerticallyWithPadding
-- @param  padding

-----------------------
-- @function [parent=#CCMenu] alignItemsHorizontally

-----------------------
-- @function [parent=#CCMenu] alignItemsHorizontallyWithPadding
-- @param  padding

-----------------------
-- @function [parent=#CCMenu] setHandlerPriority
-- @param  newPriority

-----------------------
-- @function [parent=#CCMenu] addChild
-- @param  child
-- @param  0
-- @param  1

-----------------------
-- @function [parent=#CCMenu] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCMenu] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCMenu] setColor
-- @param  color

-----------------------
-- @function [parent=#CCMenu] getColor
-- @param  void

-----------------------
-- @function [parent=#CCMenu] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCMenu] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCMenu] isEnabled

-----------------------
-- @function [parent=#CCMenu] setEnabled
-- @param  value

-----------------------
-- @function [parent=#CCMenu] create

-----------------------
-- @function [parent=#CCMenu] createWithItem
-- @param  item

-----------------------
-- @function [parent=#CCMenu] createWithArray
-- @param  pArrayOfItems

-----------------------
return nil
