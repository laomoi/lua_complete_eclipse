-- @module CCMenu

-----------------------
-- @function [parent=#CCMenu] alignItemsVertically
-- @param  self

-----------------------
-- @function [parent=#CCMenu] alignItemsVerticallyWithPadding
-- @param  self
-- @param  padding

-----------------------
-- @function [parent=#CCMenu] alignItemsHorizontally
-- @param  self

-----------------------
-- @function [parent=#CCMenu] alignItemsHorizontallyWithPadding
-- @param  self
-- @param  padding

-----------------------
-- @function [parent=#CCMenu] setHandlerPriority
-- @param  self
-- @param  newPriority

-----------------------
-- @function [parent=#CCMenu] addChild
-- @param  self
-- @param  child
-- @param  0
-- @param  1

-----------------------
-- @function [parent=#CCMenu] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCMenu] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenu] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenu] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenu] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCMenu] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenu] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCMenu] setEnabled
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCMenu] create

-----------------------
-- @function [parent=#CCMenu] createWithItem
-- @param  item

-----------------------
-- @function [parent=#CCMenu] createWithArray
-- @param  pArrayOfItems

-----------------------
return nil
