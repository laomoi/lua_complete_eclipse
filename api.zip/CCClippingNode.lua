-- @module CCClippingNode

-----------------------
-- @function [parent=#CCClippingNode] create

-----------------------
-- @function [parent=#CCClippingNode] create
-- @param  pStencil

-----------------------
-- @function [parent=#CCClippingNode] getStencil

-----------------------
-- @function [parent=#CCClippingNode] setStencil
-- @param  pStencil

-----------------------
-- @function [parent=#CCClippingNode] getAlphaThreshold

-----------------------
-- @function [parent=#CCClippingNode] setAlphaThreshold
-- @param  fAlphaThreshold

-----------------------
-- @function [parent=#CCClippingNode] isInverted

-----------------------
-- @function [parent=#CCClippingNode] setInverted
-- @param  bInverted

-----------------------
return nil
