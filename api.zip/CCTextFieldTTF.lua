-- @module CCTextFieldTTF

-----------------------
-- @function [parent=#CCTextFieldTTF] attachWithIME

-----------------------
-- @function [parent=#CCTextFieldTTF] detachWithIME

-----------------------
-- @function [parent=#CCTextFieldTTF] getCharCount

-----------------------
-- @function [parent=#CCTextFieldTTF] setColorSpaceHolder
-- @param  val

-----------------------
-- @function [parent=#CCTextFieldTTF] getColorSpaceHolder

-----------------------
-- @function [parent=#CCTextFieldTTF] setString
-- @param  text

-----------------------
-- @function [parent=#CCTextFieldTTF] getString
-- @param  void

-----------------------
-- @function [parent=#CCTextFieldTTF] setPlaceHolder
-- @param  text

-----------------------
-- @function [parent=#CCTextFieldTTF] getPlaceHolder
-- @param  void

-----------------------
-- @function [parent=#CCTextFieldTTF] textFieldWithPlaceHolder
-- @param  placeholder
-- @param  dimensions
-- @param  alignment
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCTextFieldTTF] textFieldWithPlaceHolder
-- @param  placeholder
-- @param  fontName
-- @param  fontSize

-----------------------
return nil
