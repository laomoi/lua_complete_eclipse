-- @module CCTextFieldTTF

-----------------------
-- @function [parent=#CCTextFieldTTF] attachWithIME
-- @param  self

-----------------------
-- @function [parent=#CCTextFieldTTF] detachWithIME
-- @param  self

-----------------------
-- @function [parent=#CCTextFieldTTF] getCharCount
-- @param  self

-----------------------
-- @function [parent=#CCTextFieldTTF] setColorSpaceHolder
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCTextFieldTTF] getColorSpaceHolder
-- @param  self

-----------------------
-- @function [parent=#CCTextFieldTTF] setString
-- @param  self
-- @param  text

-----------------------
-- @function [parent=#CCTextFieldTTF] getString
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTextFieldTTF] setPlaceHolder
-- @param  self
-- @param  text

-----------------------
-- @function [parent=#CCTextFieldTTF] getPlaceHolder
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCTextFieldTTF] textFieldWithPlaceHolder
-- @param  placeholder
-- @param  dimensions
-- @param  alignment
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCTextFieldTTF] textFieldWithPlaceHolder
-- @param  placeholder
-- @param  fontName
-- @param  fontSize

-----------------------
return nil
