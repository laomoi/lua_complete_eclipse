-- @module CCLiquid

-----------------------
-- @function [parent=#CCLiquid] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCLiquid] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCLiquid] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCLiquid] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCLiquid] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude

-----------------------
return nil
