-- @module CCLiquid

-----------------------
-- @function [parent=#CCLiquid] getAmplitude
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLiquid] setAmplitude
-- @param  self
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCLiquid] getAmplitudeRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLiquid] setAmplitudeRate
-- @param  self
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCLiquid] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude

-----------------------
return nil
