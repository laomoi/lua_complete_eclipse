-- @module CCCallFunc

-----------------------
-- @function [parent=#CCCallFunc] create
-- @param  funcID

-----------------------
return nil
