-- @module CCBezierTo

-----------------------
-- @function [parent=#CCBezierTo] create
-- @param  t
-- @param  c

-----------------------
return nil
