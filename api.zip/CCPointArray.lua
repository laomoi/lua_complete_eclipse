-- @module CCPointArray

-----------------------
-- @function [parent=#CCPointArray] create
-- @param  capacity

-----------------------
-- @function [parent=#CCPointArray] add
-- @param  point

-----------------------
-- @function [parent=#CCPointArray] insert
-- @param  point
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] replace
-- @param  point
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] get
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] remove
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] removeAll
-- @param  void

-----------------------
-- @function [parent=#CCPointArray] count
-- @param  void

-----------------------
-- @function [parent=#CCPointArray] reverse
-- @param  void

-----------------------
-- @function [parent=#CCPointArray] reverseInline
-- @param  void

-----------------------
return nil
