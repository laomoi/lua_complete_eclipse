-- @module CCPointArray

-----------------------
-- @function [parent=#CCPointArray] create
-- @param  capacity

-----------------------
-- @function [parent=#CCPointArray] add
-- @param  self
-- @param  point

-----------------------
-- @function [parent=#CCPointArray] insert
-- @param  self
-- @param  point
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] replace
-- @param  self
-- @param  point
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] get
-- @param  self
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] remove
-- @param  self
-- @param  index

-----------------------
-- @function [parent=#CCPointArray] removeAll
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCPointArray] count
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCPointArray] reverse
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCPointArray] reverseInline
-- @param  self
-- @param  void

-----------------------
return nil
