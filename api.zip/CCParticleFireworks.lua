-- @module CCParticleFireworks

-----------------------
-- @function [parent=#CCParticleFireworks] create

-----------------------
return nil
