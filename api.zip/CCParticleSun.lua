-- @module CCParticleSun

-----------------------
-- @function [parent=#CCParticleSun] create

-----------------------
return nil
