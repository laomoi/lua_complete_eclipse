-- @module CCLayerGradient

-----------------------
-- @function [parent=#CCLayerGradient] setStartColor
-- @param  self
-- @param  colors

-----------------------
-- @function [parent=#CCLayerGradient] getStartColor
-- @param  self

-----------------------
-- @function [parent=#CCLayerGradient] setEndColor
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getEndColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setStartOpacity
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getStartOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setEndOpacity
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getEndOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setVector
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getVector
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setCompressedInterpolation
-- @param  self
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] isCompressedInterpolation
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] create
-- @param  start
-- @param  end
-- @param  v

-----------------------
-- @function [parent=#CCLayerGradient] create
-- @param  start
-- @param  end

-----------------------
return nil
