-- @module CCLayerGradient

-----------------------
-- @function [parent=#CCLayerGradient] setStartColor
-- @param  colors

-----------------------
-- @function [parent=#CCLayerGradient] getStartColor

-----------------------
-- @function [parent=#CCLayerGradient] setEndColor
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getEndColor
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setStartOpacity
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getStartOpacity
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setEndOpacity
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getEndOpacity
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setVector
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] getVector
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] setCompressedInterpolation
-- @param  Value

-----------------------
-- @function [parent=#CCLayerGradient] isCompressedInterpolation
-- @param  void

-----------------------
-- @function [parent=#CCLayerGradient] create
-- @param  start
-- @param  end
-- @param  v

-----------------------
-- @function [parent=#CCLayerGradient] create
-- @param  start
-- @param  end

-----------------------
return nil
