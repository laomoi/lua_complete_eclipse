-- @module CCTransitionFlipX

-----------------------
-- @function [parent=#CCTransitionFlipX] create
-- @param  t
-- @param  s
-- @param  kCCTransitionOrientationRightOver

-----------------------
return nil
