-- @module ModelBase

-----------------------
-- @field [parent=#ModelBase] idkey

-----------------------
-- @field [parent=#ModelBase] schema

-----------------------
-- @field [parent=#ModelBase] fields

-----------------------
-- @function [parent=#ModelBase] ctor
-- @param  properties

-----------------------
-- @function [parent=#ModelBase] getId

-----------------------
-- @function [parent=#ModelBase] isValidId

-----------------------
-- @function [parent=#ModelBase] setProperties
-- @param  properties

-----------------------
-- @function [parent=#ModelBase] getProperties
-- @param  fields
-- @param   filter

-----------------------
return nil
