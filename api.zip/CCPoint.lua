-- @module CCPoint

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  void

-----------------------
-- @function [parent=#CCPoint] equals
-- @param  target

-----------------------
return nil
