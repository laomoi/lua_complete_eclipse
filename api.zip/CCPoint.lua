-- @module CCPoint

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  self
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#CCPoint] CCPoint
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCPoint] equals
-- @param  self
-- @param  target

-----------------------
return nil
