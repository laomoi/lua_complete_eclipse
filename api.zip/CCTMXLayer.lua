-- @module CCTMXLayer

-----------------------
-- @function [parent=#CCTMXLayer] setLayerSize
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCTMXLayer] getLayerSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] setMapTileSize
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCTMXLayer] getMapTileSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] setTiles
-- @param  self
-- @param  pval

-----------------------
-- @function [parent=#CCTMXLayer] getTiles
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] setTileSet
-- @param  self
-- @param  pval

-----------------------
-- @function [parent=#CCTMXLayer] getTileSet
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] setLayerOrientation
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCTMXLayer] getLayerOrientation
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] setProperties
-- @param  self
-- @param  pval

-----------------------
-- @function [parent=#CCTMXLayer] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] releaseMap
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] tileAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] tileGIDAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] setTileGID
-- @param  self
-- @param  gid
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] setTileGID
-- @param  self
-- @param  gid
-- @param  tileCoordinate
-- @param  flags

-----------------------
-- @function [parent=#CCTMXLayer] removeTileAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] positionAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] setupTiles
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] setLayerName
-- @param  self
-- @param  layerName

-----------------------
-- @function [parent=#CCTMXLayer] getLayerName
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] create
-- @param  tilesetInfo
-- @param  layerInfo
-- @param  mapInfo

-----------------------
return nil
