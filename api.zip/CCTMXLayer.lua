-- @module CCTMXLayer

-----------------------
-- @function [parent=#CCTMXLayer] setLayerSize
-- @param  val

-----------------------
-- @function [parent=#CCTMXLayer] getLayerSize

-----------------------
-- @function [parent=#CCTMXLayer] setMapTileSize
-- @param  val

-----------------------
-- @function [parent=#CCTMXLayer] getMapTileSize

-----------------------
-- @function [parent=#CCTMXLayer] setTiles
-- @param  pval

-----------------------
-- @function [parent=#CCTMXLayer] getTiles

-----------------------
-- @function [parent=#CCTMXLayer] setTileSet
-- @param  pval

-----------------------
-- @function [parent=#CCTMXLayer] getTileSet

-----------------------
-- @function [parent=#CCTMXLayer] setLayerOrientation
-- @param  val

-----------------------
-- @function [parent=#CCTMXLayer] getLayerOrientation

-----------------------
-- @function [parent=#CCTMXLayer] setProperties
-- @param  pval

-----------------------
-- @function [parent=#CCTMXLayer] getProperties

-----------------------
-- @function [parent=#CCTMXLayer] releaseMap

-----------------------
-- @function [parent=#CCTMXLayer] tileAt
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] tileGIDAt
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] setTileGID
-- @param  gid
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] setTileGID
-- @param  gid
-- @param  tileCoordinate
-- @param  flags

-----------------------
-- @function [parent=#CCTMXLayer] removeTileAt
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] positionAt
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] propertyNamed
-- @param  propertyName

-----------------------
-- @function [parent=#CCTMXLayer] setupTiles

-----------------------
-- @function [parent=#CCTMXLayer] setLayerName
-- @param  layerName

-----------------------
-- @function [parent=#CCTMXLayer] getLayerName

-----------------------
-- @function [parent=#CCTMXLayer] create
-- @param  tilesetInfo
-- @param  layerInfo
-- @param  mapInfo

-----------------------
return nil
