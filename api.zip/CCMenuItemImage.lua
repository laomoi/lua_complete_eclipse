-- @module CCMenuItemImage

-----------------------
-- @function [parent=#CCMenuItemImage] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemImage] getColor
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemImage] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemImage] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemImage] setNormalSpriteFrame
-- @param  self
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] setSelectedSpriteFrame
-- @param  self
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] setDisabledSpriteFrame
-- @param  self
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] create
-- @param  normalImage
-- @param  selectedImage
-- @param  disabledImage

-----------------------
-- @function [parent=#CCMenuItemImage] create
-- @param  normalImage
-- @param  selectedImage

-----------------------
-- @function [parent=#CCMenuItemImage] create

-----------------------
return nil
