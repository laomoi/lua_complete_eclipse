-- @module CCMenuItemImage

-----------------------
-- @function [parent=#CCMenuItemImage] setColor
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemImage] getColor

-----------------------
-- @function [parent=#CCMenuItemImage] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemImage] getOpacity

-----------------------
-- @function [parent=#CCMenuItemImage] setNormalSpriteFrame
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] setSelectedSpriteFrame
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] setDisabledSpriteFrame
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] create
-- @param  normalImage
-- @param  selectedImage
-- @param  disabledImage

-----------------------
-- @function [parent=#CCMenuItemImage] create
-- @param  normalImage
-- @param  selectedImage

-----------------------
-- @function [parent=#CCMenuItemImage] create

-----------------------
return nil
