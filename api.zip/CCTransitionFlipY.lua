-- @module CCTransitionFlipY

-----------------------
-- @function [parent=#CCTransitionFlipY] create
-- @param  t
-- @param  s
-- @param  kCCTransitionOrientationUpOver

-----------------------
return nil
