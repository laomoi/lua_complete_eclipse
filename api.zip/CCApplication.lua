-- @module CCApplication

-----------------------
-- @function [parent=#CCApplication] sharedApplication

-----------------------
-- @function [parent=#CCApplication] getCurrentLanguage

-----------------------
-- @function [parent=#CCApplication] getTargetPlatform

-----------------------
return nil
