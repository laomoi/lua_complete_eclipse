-- @module CCFiniteTimeAction

-----------------------
-- @function [parent=#CCFiniteTimeAction] getDuration
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCFiniteTimeAction] setDuration
-- @param  self
-- @param  duration

-----------------------
-- @function [parent=#CCFiniteTimeAction] reverse
-- @param  self
-- @param  void

-----------------------
return nil
