-- @module CCFiniteTimeAction

-----------------------
-- @function [parent=#CCFiniteTimeAction] getDuration
-- @param  void

-----------------------
-- @function [parent=#CCFiniteTimeAction] setDuration
-- @param  duration

-----------------------
-- @function [parent=#CCFiniteTimeAction] reverse
-- @param  void

-----------------------
return nil
