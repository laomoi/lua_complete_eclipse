-- @module OpenFeint

-----------------------
return nil
