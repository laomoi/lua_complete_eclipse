-- @module CCLens3D

-----------------------
-- @function [parent=#CCLens3D] getLensEffect
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLens3D] setLensEffect
-- @param  self
-- @param  fLensEffect

-----------------------
-- @function [parent=#CCLens3D] getPosition
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLens3D] setPosition
-- @param  self
-- @param  position

-----------------------
-- @function [parent=#CCLens3D] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  radius

-----------------------
return nil
