-- @module CCLens3D

-----------------------
-- @function [parent=#CCLens3D] getLensEffect
-- @param  void

-----------------------
-- @function [parent=#CCLens3D] setLensEffect
-- @param  fLensEffect

-----------------------
-- @function [parent=#CCLens3D] getPosition
-- @param  void

-----------------------
-- @function [parent=#CCLens3D] setPosition
-- @param  position

-----------------------
-- @function [parent=#CCLens3D] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  radius

-----------------------
return nil
