-- @module CCDirector

-----------------------
-- @function [parent=#CCDirector] getRunningScene
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getAnimationInterval
-- @param  void

-----------------------
-- @function [parent=#CCDirector] isDisplayStats
-- @param  void

-----------------------
-- @function [parent=#CCDirector] setDisplayStats
-- @param  bDisplayStats

-----------------------
-- @function [parent=#CCDirector] isPaused
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getTotalFrames
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getOpenGLView
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getWinSize
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getWinSizeInPixels
-- @param  void

-----------------------
-- @function [parent=#CCDirector] convertToGL
-- @param  obPoint

-----------------------
-- @function [parent=#CCDirector] convertToUI
-- @param  obPoint

-----------------------
-- @function [parent=#CCDirector] pause

-----------------------
-- @function [parent=#CCDirector] resume

-----------------------
-- @function [parent=#CCDirector] purgeCachedData
-- @param  void

-----------------------
-- @function [parent=#CCDirector] runWithScene
-- @param  pScene

-----------------------
-- @function [parent=#CCDirector] pushScene
-- @param  pScene

-----------------------
-- @function [parent=#CCDirector] popScene
-- @param  void

-----------------------
-- @function [parent=#CCDirector] replaceScene
-- @param  pScene

-----------------------
-- @function [parent=#CCDirector] getContentScaleFactor
-- @param  void

-----------------------
-- @function [parent=#CCDirector] setContentScaleFactor
-- @param  scaleFactor

-----------------------
-- @function [parent=#CCDirector] getScheduler

-----------------------
-- @function [parent=#CCDirector] getActionManager

-----------------------
-- @function [parent=#CCDirector] getTouchDispatcher

-----------------------
-- @function [parent=#CCDirector] getKeypadDispatcher

-----------------------
-- @function [parent=#CCDirector] getAccelerometer

-----------------------
-- @function [parent=#CCDirector] setDepthTest
-- @param  var

-----------------------
-- @function [parent=#CCDirector] setProjection
-- @param  kProjection

-----------------------
-- @function [parent=#CCDirector] getProjection
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getNotificationNode

-----------------------
-- @function [parent=#CCDirector] setNotificationNode
-- @param  node

-----------------------
-- @function [parent=#CCDirector] getZEye
-- @param  void

-----------------------
-- @function [parent=#CCDirector] getVisibleSize

-----------------------
-- @function [parent=#CCDirector] getVisibleOrigin

-----------------------
-- @function [parent=#CCDirector] sharedDirector
-- @param  void

-----------------------
return nil
