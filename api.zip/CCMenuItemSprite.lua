-- @module CCMenuItemSprite

-----------------------
-- @function [parent=#CCMenuItemSprite] setColor
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemSprite] getColor

-----------------------
-- @function [parent=#CCMenuItemSprite] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemSprite] getOpacity

-----------------------
-- @function [parent=#CCMenuItemSprite] setNormalImage
-- @param  pImage

-----------------------
-- @function [parent=#CCMenuItemSprite] getNormalImage

-----------------------
-- @function [parent=#CCMenuItemSprite] setSelectedImage
-- @param  pImage

-----------------------
-- @function [parent=#CCMenuItemSprite] getSelectedImage

-----------------------
-- @function [parent=#CCMenuItemSprite] setDisabledImage
-- @param  pImage

-----------------------
-- @function [parent=#CCMenuItemSprite] getDisabledImage

-----------------------
-- @function [parent=#CCMenuItemSprite] setOpacityModifyRGB
-- @param  bValue

-----------------------
-- @function [parent=#CCMenuItemSprite] isOpacityModifyRGB
-- @param  void

-----------------------
-- @function [parent=#CCMenuItemSprite] create
-- @param  normalSprite
-- @param  selectedSprite

-----------------------
return nil
