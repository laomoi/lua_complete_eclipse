-- @module CCMenuItemSprite

-----------------------
-- @function [parent=#CCMenuItemSprite] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemSprite] getColor
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCMenuItemSprite] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setNormalImage
-- @param  self
-- @param  pImage

-----------------------
-- @function [parent=#CCMenuItemSprite] getNormalImage
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setSelectedImage
-- @param  self
-- @param  pImage

-----------------------
-- @function [parent=#CCMenuItemSprite] getSelectedImage
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setDisabledImage
-- @param  self
-- @param  pImage

-----------------------
-- @function [parent=#CCMenuItemSprite] getDisabledImage
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCMenuItemSprite] isOpacityModifyRGB
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenuItemSprite] create
-- @param  normalSprite
-- @param  selectedSprite

-----------------------
return nil
