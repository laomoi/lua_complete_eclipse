-- @module CCCircleShape

-----------------------
-- @function [parent=#CCCircleShape] create
-- @param  radius

-----------------------
-- @function [parent=#CCCircleShape] getRadius
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setRadius
-- @param  radius

-----------------------
-- @function [parent=#CCCircleShape] getAngle
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setAngle
-- @param  angle

-----------------------
-- @function [parent=#CCCircleShape] getSegments
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setSegments
-- @param  segments

-----------------------
-- @function [parent=#CCCircleShape] isDrawLineToCenter
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setDrawLineToCenter
-- @param  drawLineToCenter

-----------------------
-- @function [parent=#CCCircleShape] getScaleX
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setScaleX
-- @param  xScale

-----------------------
-- @function [parent=#CCCircleShape] getScaleY
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setScaleY
-- @param  yScale

-----------------------
return nil
