-- @module CCShapeNodeExtend

-----------------------
-- @field [parent=#CCShapeNodeExtend] __index

-----------------------
-- @function [parent=#CCShapeNodeExtend] extend
-- @param  target

-----------------------
-- @function [parent=#CCShapeNodeExtend] setColor
-- @param  r
-- @param   g
-- @param   b
-- @param   a

-----------------------
return nil
