-- @module CCParticleSnow

-----------------------
-- @function [parent=#CCParticleSnow] create

-----------------------
return nil
