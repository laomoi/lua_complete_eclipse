-- @module CCRenderTexture

-----------------------
-- @function [parent=#CCRenderTexture] getSprite
-- @param  self

-----------------------
-- @function [parent=#CCRenderTexture] setSprite
-- @param  self
-- @param  psprite

-----------------------
-- @function [parent=#CCRenderTexture] begin
-- @param  self

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a
-- @param  depthValue
-- @param  stencilValue

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a
-- @param  depthValue

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a

-----------------------
-- @function [parent=#CCRenderTexture] clear
-- @param  self
-- @param  r
-- @param  g
-- @param  b
-- @param  a

-----------------------
-- @function [parent=#CCRenderTexture] clearDepth
-- @param  self
-- @param  depthValue

-----------------------
-- @function [parent=#CCRenderTexture] clearStencil
-- @param  self
-- @param  stencilValue

-----------------------
-- @function [parent=#CCRenderTexture] newCCImage
-- @param  self

-----------------------
-- @function [parent=#CCRenderTexture] saveToFile
-- @param  self
-- @param  name
-- @param  format

-----------------------
-- @function [parent=#CCRenderTexture] saveToFile
-- @param  self
-- @param  szFilePath

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h
-- @param  eFormat
-- @param  uDepthStencilFormat

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h
-- @param  eFormat

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h

-----------------------
return nil
