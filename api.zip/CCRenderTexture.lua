-- @module CCRenderTexture

-----------------------
-- @function [parent=#CCRenderTexture] getSprite

-----------------------
-- @function [parent=#CCRenderTexture] setSprite
-- @param  psprite

-----------------------
-- @function [parent=#CCRenderTexture] begin

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  r
-- @param  g
-- @param  b
-- @param  a
-- @param  depthValue
-- @param  stencilValue

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  r
-- @param  g
-- @param  b
-- @param  a
-- @param  depthValue

-----------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param  r
-- @param  g
-- @param  b
-- @param  a

-----------------------
-- @function [parent=#CCRenderTexture] clear
-- @param  r
-- @param  g
-- @param  b
-- @param  a

-----------------------
-- @function [parent=#CCRenderTexture] clearDepth
-- @param  depthValue

-----------------------
-- @function [parent=#CCRenderTexture] clearStencil
-- @param  stencilValue

-----------------------
-- @function [parent=#CCRenderTexture] newCCImage

-----------------------
-- @function [parent=#CCRenderTexture] saveToFile
-- @param  name
-- @param  format

-----------------------
-- @function [parent=#CCRenderTexture] saveToFile
-- @param  szFilePath

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h
-- @param  eFormat
-- @param  uDepthStencilFormat

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h
-- @param  eFormat

-----------------------
-- @function [parent=#CCRenderTexture] create
-- @param  w
-- @param  h

-----------------------
return nil
