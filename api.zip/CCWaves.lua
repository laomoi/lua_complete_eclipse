-- @module CCWaves

-----------------------
-- @function [parent=#CCWaves] getAmplitude
-- @param  void

-----------------------
-- @function [parent=#CCWaves] setAmplitude
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCWaves] getAmplitudeRate
-- @param  void

-----------------------
-- @function [parent=#CCWaves] setAmplitudeRate
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCWaves] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude
-- @param  horizontal
-- @param  vertical

-----------------------
return nil
