-- @module CCWaves

-----------------------
-- @function [parent=#CCWaves] getAmplitude
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCWaves] setAmplitude
-- @param  self
-- @param  fAmplitude

-----------------------
-- @function [parent=#CCWaves] getAmplitudeRate
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCWaves] setAmplitudeRate
-- @param  self
-- @param  fAmplitudeRate

-----------------------
-- @function [parent=#CCWaves] create
-- @param  duration
-- @param  gridSize
-- @param  waves
-- @param  amplitude
-- @param  horizontal
-- @param  vertical

-----------------------
return nil
