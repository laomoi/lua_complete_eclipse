-- @module CCSpawn

-----------------------
-- @function [parent=#CCSpawn] createWithTwoActions
-- @param  pAction1
-- @param  pAction2

-----------------------
-- @function [parent=#CCSpawn] create
-- @param  actions

-----------------------
return nil
