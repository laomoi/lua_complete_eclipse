-- @module CCAnimationCache

-----------------------
-- @function [parent=#CCAnimationCache] addAnimation
-- @param  animation
-- @param  name

-----------------------
-- @function [parent=#CCAnimationCache] removeAnimationByName
-- @param  name

-----------------------
-- @function [parent=#CCAnimationCache] animationByName
-- @param  name

-----------------------
-- @function [parent=#CCAnimationCache] addAnimationsWithDictionary
-- @param  dictionary

-----------------------
-- @function [parent=#CCAnimationCache] addAnimationsWithFile
-- @param  plist

-----------------------
-- @function [parent=#CCAnimationCache] sharedAnimationCache
-- @param  void

-----------------------
-- @function [parent=#CCAnimationCache] purgeSharedAnimationCache
-- @param  void

-----------------------
return nil
