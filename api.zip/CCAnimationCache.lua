-- @module CCAnimationCache

-----------------------
-- @function [parent=#CCAnimationCache] addAnimation
-- @param  self
-- @param  animation
-- @param  name

-----------------------
-- @function [parent=#CCAnimationCache] removeAnimationByName
-- @param  self
-- @param  name

-----------------------
-- @function [parent=#CCAnimationCache] animationByName
-- @param  self
-- @param  name

-----------------------
-- @function [parent=#CCAnimationCache] addAnimationsWithDictionary
-- @param  self
-- @param  dictionary

-----------------------
-- @function [parent=#CCAnimationCache] addAnimationsWithFile
-- @param  self
-- @param  plist

-----------------------
-- @function [parent=#CCAnimationCache] sharedAnimationCache
-- @param  void

-----------------------
-- @function [parent=#CCAnimationCache] purgeSharedAnimationCache
-- @param  void

-----------------------
return nil
