-- @module CCTransitionFlipAngular

-----------------------
-- @function [parent=#CCTransitionFlipAngular] create
-- @param  t
-- @param  s
-- @param  kCCTransitionOrientationRightOver

-----------------------
return nil
