-- @module CCLayerExtend

-----------------------
-- @field [parent=#CCLayerExtend] __index

-----------------------
-- @function [parent=#CCLayerExtend] extend
-- @param  target

-----------------------
-- @function [parent=#CCLayerExtend] addTouchEventListener
-- @param  listener
-- @param   isMultiTouches
-- @param   priority
-- @param   swallowsTouches

-----------------------
-- @function [parent=#CCLayerExtend] removeTouchEventListener

-----------------------
-- @function [parent=#CCLayerExtend] addKeypadEventListener
-- @param  listener

-----------------------
-- @function [parent=#CCLayerExtend] removeKeypadEventListener

-----------------------
-- @function [parent=#CCLayerExtend] addScriptAccelerateHandler
-- @param  listener

-----------------------
-- @function [parent=#CCLayerExtend] removeScriptAccelerateHandler

-----------------------
return nil
