-- @module CCLayerExtend

-----------------------
-- @field [parent=#CCLayerExtend] __index

-----------------------
-- @function [parent=#CCLayerExtend] extend
-- @param  target

-----------------------
-- @function [parent=#CCLayerExtend] addTouchEventListener
-- @param  self
-- @param  listener
-- @param  isMultiTouches
-- @param  priority
-- @param  swallowsTouches

-----------------------
-- @function [parent=#CCLayerExtend] removeTouchEventListener
-- @param  self

-----------------------
-- @function [parent=#CCLayerExtend] addKeypadEventListener
-- @param  self
-- @param  listener

-----------------------
-- @function [parent=#CCLayerExtend] removeKeypadEventListener
-- @param  self

-----------------------
-- @function [parent=#CCLayerExtend] addScriptAccelerateHandler
-- @param  self
-- @param  listener

-----------------------
-- @function [parent=#CCLayerExtend] removeScriptAccelerateHandler
-- @param  self

-----------------------
return nil
