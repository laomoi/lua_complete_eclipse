-- @module CCLayer

-----------------------
-- @function [parent=#CCLayer] setTouchEnabled
-- @param  bValue

-----------------------
-- @function [parent=#CCLayer] isTouchEnabled

-----------------------
-- @function [parent=#CCLayer] setAccelerometerEnabled
-- @param  bValue

-----------------------
-- @function [parent=#CCLayer] isAccelerometerEnabled

-----------------------
-- @function [parent=#CCLayer] setKeypadEnabled
-- @param  bValue

-----------------------
-- @function [parent=#CCLayer] isKeypadEnabled

-----------------------
-- @function [parent=#CCLayer] setTouchPriority
-- @param  priority

-----------------------
-- @function [parent=#CCLayer] getTouchPriority

-----------------------
-- @function [parent=#CCLayer] unregisterScriptTouchHandler

-----------------------
-- @function [parent=#CCLayer] registerScriptKeypadHandler
-- @param  nHandler

-----------------------
-- @function [parent=#CCLayer] unregisterScriptKeypadHandler
-- @param  void

-----------------------
-- @function [parent=#CCLayer] registerScriptAccelerateHandler
-- @param  nHandler

-----------------------
-- @function [parent=#CCLayer] unregisterScriptAccelerateHandler
-- @param  void

-----------------------
-- @function [parent=#CCLayer] create
-- @param  void

-----------------------
return nil
