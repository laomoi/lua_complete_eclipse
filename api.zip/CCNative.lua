-- @module CCNative

-----------------------
-- @function [parent=#CCNative] showActivityIndicator
-- @param  void

-----------------------
-- @function [parent=#CCNative] hideActivityIndicator
-- @param  void

-----------------------
-- @function [parent=#CCNative] addAlertButton
-- @param  buttonTitle

-----------------------
-- @function [parent=#CCNative] showAlertLua
-- @param  listener

-----------------------
-- @function [parent=#CCNative] cancelAlert
-- @param  void

-----------------------
-- @function [parent=#CCNative] getOpenUDID
-- @param  void

-----------------------
-- @function [parent=#CCNative] openURL
-- @param  url

-----------------------
-- @function [parent=#CCNative] getInputText
-- @param  title
-- @param  message
-- @param  defaultValue

-----------------------
-- @function [parent=#CCNative] getDeviceName
-- @param  void

-----------------------
-- @function [parent=#CCNative] vibrate

-----------------------
return nil
