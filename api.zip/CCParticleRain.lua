-- @module CCParticleRain

-----------------------
-- @function [parent=#CCParticleRain] create

-----------------------
return nil
