-- @module CCSpriteExtend

-----------------------
-- @field [parent=#CCSpriteExtend] __index

-----------------------
-- @function [parent=#CCSpriteExtend] extend
-- @param  target

-----------------------
-- @function [parent=#CCSpriteExtend] playAnimationOnce
-- @param  animation
-- @param  removeWhenFinished
-- @param  onComplete
-- @param  delay

-----------------------
-- @function [parent=#CCSpriteExtend] playAnimationForever
-- @param  animation
-- @param  isRestoreOriginalFrame
-- @param  delay

-----------------------
-- @function [parent=#CCSpriteExtend] autoCleanup

-----------------------
return nil
