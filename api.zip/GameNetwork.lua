-- @module GameNetwork

-----------------------
-- @function [parent=#GameNetwork] init
-- @param  providerName
-- @param   params

-----------------------
-- @function [parent=#GameNetwork] request
-- @param  command
-- @param   ...

-----------------------
-- @function [parent=#GameNetwork] show
-- @param  command
-- @param   ...

-----------------------
-- @function [parent=#GameNetwork] exit

-----------------------
return nil
