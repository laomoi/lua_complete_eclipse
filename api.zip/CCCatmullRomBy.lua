-- @module CCCatmullRomBy

-----------------------
-- @function [parent=#CCCatmullRomBy] create
-- @param  dt
-- @param  points

-----------------------
return nil
