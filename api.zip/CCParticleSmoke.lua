-- @module CCParticleSmoke

-----------------------
-- @function [parent=#CCParticleSmoke] create

-----------------------
return nil
