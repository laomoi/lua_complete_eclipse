-- @module CCEaseElasticOut

-----------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param  pAction
-- @param  3

-----------------------
return nil
