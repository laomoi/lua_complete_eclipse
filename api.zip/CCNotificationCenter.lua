-- @module CCNotificationCenter

-----------------------
-- @function [parent=#CCNotificationCenter] sharedNotificationCenter
-- @param  void

-----------------------
-- @function [parent=#CCNotificationCenter] registerScriptObserver
-- @param  handler

-----------------------
-- @function [parent=#CCNotificationCenter] unregisterScriptObserver
-- @param  void

-----------------------
-- @function [parent=#CCNotificationCenter] postNotification
-- @param  name

-----------------------
return nil
