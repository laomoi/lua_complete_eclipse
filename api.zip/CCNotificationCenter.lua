-- @module CCNotificationCenter

-----------------------
-- @function [parent=#CCNotificationCenter] registerScriptObserver
-- @param  self
-- @param  handler

-----------------------
-- @function [parent=#CCNotificationCenter] unregisterScriptObserver
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCNotificationCenter] postNotification
-- @param  self
-- @param  name

-----------------------
return nil
