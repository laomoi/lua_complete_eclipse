-- @module CCOrbitCamera

-----------------------
-- @function [parent=#CCOrbitCamera] sphericalRadius
-- @param  r
-- @param  zenith
-- @param  azimuth

-----------------------
-- @function [parent=#CCOrbitCamera] create
-- @param  t
-- @param  radius
-- @param  deltaRadius
-- @param  angleZ
-- @param  deltaAngleZ
-- @param  angleX
-- @param  deltaAngleX

-----------------------
return nil
