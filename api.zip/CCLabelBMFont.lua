-- @module CCLabelBMFont

-----------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param  self
-- @param  label
-- @param  fromUpdate

-----------------------
-- @function [parent=#CCLabelBMFont] setCString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelBMFont] getString
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] updateString
-- @param  self
-- @param  fromUpdate

-----------------------
-- @function [parent=#CCLabelBMFont] setAnchorPoint
-- @param  self
-- @param  var

-----------------------
-- @function [parent=#CCLabelBMFont] setAlignment
-- @param  self
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelBMFont] setWidth
-- @param  self
-- @param  width

-----------------------
-- @function [parent=#CCLabelBMFont] setLineBreakWithoutSpace
-- @param  self
-- @param  breakWithoutSpace

-----------------------
-- @function [parent=#CCLabelBMFont] setScale
-- @param  self
-- @param  scale

-----------------------
-- @function [parent=#CCLabelBMFont] setScaleX
-- @param  self
-- @param  scaleX

-----------------------
-- @function [parent=#CCLabelBMFont] setScaleY
-- @param  self
-- @param  scaleY

-----------------------
-- @function [parent=#CCLabelBMFont] setFntFile
-- @param  self
-- @param  fntFile

-----------------------
-- @function [parent=#CCLabelBMFont] getFntFile
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCLabelBMFont] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] getOpacity
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCLabelBMFont] isOpacityModifyRGB
-- @param  self

-----------------------
-- @function [parent=#CCLabelBMFont] setOpacityModifyRGB
-- @param  self
-- @param  isOpacityModifyRGB

-----------------------
-- @function [parent=#CCLabelBMFont] purgeCachedData

-----------------------
-- @function [parent=#CCLabelBMFont] create
-- @param  str
-- @param  fntFile
-- @param  kCCLabelAutomaticWidth
-- @param  kCCTextAlignmentLeft
-- @param  0
-- @param  0

-----------------------
-- @function [parent=#CCLabelBMFont] create

-----------------------
return nil
