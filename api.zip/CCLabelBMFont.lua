-- @module CCLabelBMFont

-----------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param  label

-----------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param  label
-- @param  fromUpdate

-----------------------
-- @function [parent=#CCLabelBMFont] setCString
-- @param  label

-----------------------
-- @function [parent=#CCLabelBMFont] getString
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] updateString
-- @param  fromUpdate

-----------------------
-- @function [parent=#CCLabelBMFont] setAnchorPoint
-- @param  var

-----------------------
-- @function [parent=#CCLabelBMFont] setAlignment
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelBMFont] setWidth
-- @param  width

-----------------------
-- @function [parent=#CCLabelBMFont] setLineBreakWithoutSpace
-- @param  breakWithoutSpace

-----------------------
-- @function [parent=#CCLabelBMFont] setScale
-- @param  scale

-----------------------
-- @function [parent=#CCLabelBMFont] setScaleX
-- @param  scaleX

-----------------------
-- @function [parent=#CCLabelBMFont] setScaleY
-- @param  scaleY

-----------------------
-- @function [parent=#CCLabelBMFont] setFntFile
-- @param  fntFile

-----------------------
-- @function [parent=#CCLabelBMFont] getFntFile

-----------------------
-- @function [parent=#CCLabelBMFont] setColor
-- @param  color

-----------------------
-- @function [parent=#CCLabelBMFont] getColor
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] getOpacity
-- @param  void

-----------------------
-- @function [parent=#CCLabelBMFont] setOpacity
-- @param  opacity

-----------------------
-- @function [parent=#CCLabelBMFont] isOpacityModifyRGB

-----------------------
-- @function [parent=#CCLabelBMFont] setOpacityModifyRGB
-- @param  isOpacityModifyRGB

-----------------------
-- @function [parent=#CCLabelBMFont] purgeCachedData

-----------------------
-- @function [parent=#CCLabelBMFont] create
-- @param  str
-- @param  fntFile
-- @param  kCCLabelAutomaticWidth
-- @param  kCCTextAlignmentLeft
-- @param  0
-- @param  0

-----------------------
-- @function [parent=#CCLabelBMFont] create

-----------------------
return nil
