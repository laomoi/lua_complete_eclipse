-- @module CCEaseInOut

-----------------------
-- @function [parent=#CCEaseInOut] create
-- @param  pAction
-- @param  fRate

-----------------------
return nil
