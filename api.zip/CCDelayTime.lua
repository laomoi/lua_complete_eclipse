-- @module CCDelayTime

-----------------------
-- @function [parent=#CCDelayTime] create
-- @param  d

-----------------------
return nil
