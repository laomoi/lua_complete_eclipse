-- @module CCEGLViewProtocol

-----------------------
-- @function [parent=#CCEGLViewProtocol] getFrameSize

-----------------------
-- @function [parent=#CCEGLViewProtocol] setFrameSize
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCEGLViewProtocol] getVisibleSize

-----------------------
-- @function [parent=#CCEGLViewProtocol] getVisibleOrigin

-----------------------
-- @function [parent=#CCEGLViewProtocol] setDesignResolutionSize
-- @param  width
-- @param  height
-- @param  resolutionPolicy

-----------------------
-- @function [parent=#CCEGLViewProtocol] getDesignResolutionSize

-----------------------
-- @function [parent=#CCEGLViewProtocol] setViewPortInPoints
-- @param  x
-- @param  y
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCEGLViewProtocol] setScissorInPoints
-- @param  x
-- @param  y
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCEGLViewProtocol] getViewPortRect

-----------------------
-- @function [parent=#CCEGLViewProtocol] getScaleX

-----------------------
-- @function [parent=#CCEGLViewProtocol] getScaleY

-----------------------
return nil
