-- @module CCEaseElastic

-----------------------
-- @function [parent=#CCEaseElastic] getPeriod
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCEaseElastic] setPeriod
-- @param  self
-- @param  fPeriod

-----------------------
-- @function [parent=#CCEaseElastic] create
-- @param  pAction
-- @param  3

-----------------------
return nil
