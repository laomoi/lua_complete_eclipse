-- @module CCEaseElastic

-----------------------
-- @function [parent=#CCEaseElastic] getPeriod
-- @param  void

-----------------------
-- @function [parent=#CCEaseElastic] setPeriod
-- @param  fPeriod

-----------------------
-- @function [parent=#CCEaseElastic] create
-- @param  pAction
-- @param  3

-----------------------
return nil
