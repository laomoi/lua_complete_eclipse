-- @module CCParticleFlower

-----------------------
-- @function [parent=#CCParticleFlower] create

-----------------------
return nil
