-- @module CCEaseElasticIn

-----------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param  pAction
-- @param  3

-----------------------
return nil
