-- @module CCTransitionProgress

-----------------------
-- @function [parent=#CCTransitionProgress] create
-- @param  t
-- @param  scene

-----------------------
return nil
