-- @module CCTintTo

-----------------------
-- @function [parent=#CCTintTo] create
-- @param  duration
-- @param  red
-- @param  green
-- @param  blue

-----------------------
return nil
