-- @module json

-----------------------
-- @function [parent=#json] encode
-- @param  var
-- @param   isDebug

-----------------------
-- @function [parent=#json] decode
-- @param  text
-- @param   isDebug

-----------------------
return nil
