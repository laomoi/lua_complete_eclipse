-- @module CCFileUtils

-----------------------
-- @function [parent=#CCFileUtils] sharedFileUtils

-----------------------
-- @function [parent=#CCFileUtils] purgeFileUtils

-----------------------
-- @function [parent=#CCFileUtils] purgeCachedEntries
-- @param  self

-----------------------
-- @function [parent=#CCFileUtils] fullPathForFilename
-- @param  self
-- @param  pszFileName

-----------------------
-- @function [parent=#CCFileUtils] loadFilenameLookupDictionaryFromFile
-- @param  self
-- @param  filename

-----------------------
-- @function [parent=#CCFileUtils] fullPathFromRelativeFile
-- @param  self
-- @param  pszFilename
-- @param  pszRelativeFile

-----------------------
-- @function [parent=#CCFileUtils] addSearchResolutionsOrder
-- @param  self
-- @param  order

-----------------------
-- @function [parent=#CCFileUtils] setSearchRootPath
-- @param  self
-- @param  rootPath

-----------------------
-- @function [parent=#CCFileUtils] addSearchPath
-- @param  self
-- @param  path

-----------------------
-- @function [parent=#CCFileUtils] getWriteablePath
-- @param  self

-----------------------
-- @function [parent=#CCFileUtils] getDocumentsPath
-- @param  self

-----------------------
-- @function [parent=#CCFileUtils] setPopupNotify
-- @param  self
-- @param  bNotify

-----------------------
-- @function [parent=#CCFileUtils] isPopupNotify
-- @param  self

-----------------------
return nil
