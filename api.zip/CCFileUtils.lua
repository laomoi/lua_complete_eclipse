-- @module CCFileUtils

-----------------------
-- @function [parent=#CCFileUtils] sharedFileUtils

-----------------------
-- @function [parent=#CCFileUtils] purgeFileUtils

-----------------------
-- @function [parent=#CCFileUtils] purgeCachedEntries

-----------------------
-- @function [parent=#CCFileUtils] fullPathForFilename
-- @param  pszFileName

-----------------------
-- @function [parent=#CCFileUtils] loadFilenameLookupDictionaryFromFile
-- @param  filename

-----------------------
-- @function [parent=#CCFileUtils] fullPathFromRelativeFile
-- @param  pszFilename
-- @param  pszRelativeFile

-----------------------
-- @function [parent=#CCFileUtils] addSearchResolutionsOrder
-- @param  order

-----------------------
-- @function [parent=#CCFileUtils] setSearchRootPath
-- @param  rootPath

-----------------------
-- @function [parent=#CCFileUtils] addSearchPath
-- @param  path

-----------------------
-- @function [parent=#CCFileUtils] getWriteablePath

-----------------------
-- @function [parent=#CCFileUtils] getDocumentsPath

-----------------------
-- @function [parent=#CCFileUtils] setPopupNotify
-- @param  bNotify

-----------------------
-- @function [parent=#CCFileUtils] isPopupNotify

-----------------------
return nil
