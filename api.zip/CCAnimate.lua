-- @module CCAnimate

-----------------------
-- @function [parent=#CCAnimate] getAnimation
-- @param  void

-----------------------
-- @function [parent=#CCAnimate] setAnimation
-- @param  pAnimation

-----------------------
-- @function [parent=#CCAnimate] create
-- @param  pAnimation

-----------------------
return nil
