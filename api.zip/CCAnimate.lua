-- @module CCAnimate

-----------------------
-- @function [parent=#CCAnimate] getAnimation
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAnimate] setAnimation
-- @param  self
-- @param  pAnimation

-----------------------
-- @function [parent=#CCAnimate] create
-- @param  pAnimation

-----------------------
return nil
