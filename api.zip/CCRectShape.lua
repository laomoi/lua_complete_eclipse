-- @module CCRectShape

-----------------------
-- @function [parent=#CCRectShape] create
-- @param  size

-----------------------
-- @function [parent=#CCRectShape] getSize
-- @param  void

-----------------------
-- @function [parent=#CCRectShape] setSize
-- @param  size

-----------------------
-- @function [parent=#CCRectShape] isFill
-- @param  void

-----------------------
-- @function [parent=#CCRectShape] setFill
-- @param  fill

-----------------------
return nil
