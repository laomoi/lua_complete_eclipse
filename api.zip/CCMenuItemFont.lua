-- @module CCMenuItemFont

-----------------------
-- @function [parent=#CCMenuItemFont] setFontSize
-- @param  s

-----------------------
-- @function [parent=#CCMenuItemFont] fontSize

-----------------------
-- @function [parent=#CCMenuItemFont] setFontName
-- @param  name

-----------------------
-- @function [parent=#CCMenuItemFont] fontName

-----------------------
-- @function [parent=#CCMenuItemFont] setFontSizeObj
-- @param  s

-----------------------
-- @function [parent=#CCMenuItemFont] fontSizeObj

-----------------------
-- @function [parent=#CCMenuItemFont] setFontNameObj
-- @param  name

-----------------------
-- @function [parent=#CCMenuItemFont] fontNameObj

-----------------------
-- @function [parent=#CCMenuItemFont] create
-- @param  value

-----------------------
return nil
