-- @module CCMenuItemFont

-----------------------
-- @function [parent=#CCMenuItemFont] setFontSize
-- @param  s

-----------------------
-- @function [parent=#CCMenuItemFont] fontSize

-----------------------
-- @function [parent=#CCMenuItemFont] setFontName
-- @param  name

-----------------------
-- @function [parent=#CCMenuItemFont] fontName

-----------------------
-- @function [parent=#CCMenuItemFont] setFontSizeObj
-- @param  self
-- @param  s

-----------------------
-- @function [parent=#CCMenuItemFont] fontSizeObj
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemFont] setFontNameObj
-- @param  self
-- @param  name

-----------------------
-- @function [parent=#CCMenuItemFont] fontNameObj
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemFont] create
-- @param  value

-----------------------
return nil
