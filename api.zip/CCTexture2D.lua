-- @module CCTexture2D

-----------------------
-- @function [parent=#CCTexture2D] getPixelFormat

-----------------------
-- @function [parent=#CCTexture2D] getPixelsWide

-----------------------
-- @function [parent=#CCTexture2D] getPixelsHigh

-----------------------
-- @function [parent=#CCTexture2D] getName

-----------------------
-- @function [parent=#CCTexture2D] getContentSizeInPixels

-----------------------
-- @function [parent=#CCTexture2D] setMaxS
-- @param  val

-----------------------
-- @function [parent=#CCTexture2D] getMaxS

-----------------------
-- @function [parent=#CCTexture2D] getMaxT

-----------------------
-- @function [parent=#CCTexture2D] setMaxT
-- @param  val

-----------------------
-- @function [parent=#CCTexture2D] hasPremultipliedAlpha

-----------------------
-- @function [parent=#CCTexture2D] hasMipmaps

-----------------------
-- @function [parent=#CCTexture2D] drawAtPoint
-- @param  point

-----------------------
-- @function [parent=#CCTexture2D] drawInRect
-- @param  rect

-----------------------
-- @function [parent=#CCTexture2D] getContentSize
-- @param  void

-----------------------
-- @function [parent=#CCTexture2D] setTexParameters
-- @param  texParams

-----------------------
-- @function [parent=#CCTexture2D] setAntiAliasTexParameters

-----------------------
-- @function [parent=#CCTexture2D] setAliasTexParameters

-----------------------
-- @function [parent=#CCTexture2D] generateMipmap

-----------------------
-- @function [parent=#CCTexture2D] stringForFormat

-----------------------
-- @function [parent=#CCTexture2D] bitsPerPixelForFormat

-----------------------
-- @function [parent=#CCTexture2D] bitsPerPixelForFormat
-- @param  format

-----------------------
-- @function [parent=#CCTexture2D] setDefaultAlphaPixelFormat
-- @param  format

-----------------------
-- @function [parent=#CCTexture2D] defaultAlphaPixelFormat

-----------------------
return nil
